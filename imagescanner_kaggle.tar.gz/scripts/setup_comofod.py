"""
scripts/setup_comofod.py
========================
Run this ONCE in a Kaggle notebook cell to reorganise the flat CoMoFoD
dataset into the three sub-folders that config.py expects:

    data/comofod/original/   <- *_B.png  (Background / authentic)
    data/comofod/forged/     <- *_F.png  (Forged copy-move)
    data/comofod/masks/      <- *_M.png  (Ground-truth masks)

CoMoFoD standard naming convention
------------------------------------
  <id>_B.png   = Background  (original un-tampered image)
  <id>_F.png   = Forged      (copy-move tampered image)
  <id>_M.png   = Mask        (binary ground-truth mask)

Usage (in a Kaggle notebook cell)
-----------------------------------
    !python scripts/setup_comofod.py \
        --src /kaggle/input/comofod/comofod_small \
        --dst /kaggle/working/data/comofod
"""

import argparse
import os
import shutil
import sys


def setup(src: str, dst: str, dry_run: bool = False) -> None:
    if not os.path.isdir(src):
        print(f"[ERROR] Source folder not found: {src}")
        sys.exit(1)

    # Create the three destination sub-folders
    original_dir = os.path.join(dst, "original")
    forged_dir   = os.path.join(dst, "forged")
    masks_dir    = os.path.join(dst, "masks")

    for d in (original_dir, forged_dir, masks_dir):
        if not dry_run:
            os.makedirs(d, exist_ok=True)

    # Walk the source directory (handles both flat and nested layouts)
    counts = {"original": 0, "forged": 0, "masks": 0, "skipped": 0}
    for root, _, files in os.walk(src):
        for fname in sorted(files):
            fpath = os.path.join(root, fname)
            name_up = fname.upper()

            if name_up.endswith("_B.PNG") or name_up.endswith("_B.JPG"):
                dest = os.path.join(original_dir, fname)
                key  = "original"
            elif name_up.endswith("_F.PNG") or name_up.endswith("_F.JPG"):
                dest = os.path.join(forged_dir, fname)
                key  = "forged"
            elif name_up.endswith("_M.PNG") or name_up.endswith("_M.JPG"):
                dest = os.path.join(masks_dir, fname)
                key  = "masks"
            else:
                counts["skipped"] += 1
                continue

            counts[key] += 1
            if dry_run:
                print(f"  [DRY] {fname} -> {key}/")
            else:
                shutil.copy2(fpath, dest)

    print("\n-- CoMoFoD setup complete --")
    print(f"  original/ : {counts['original']:>5} files  ->  {original_dir}")
    print(f"  forged/   : {counts['forged']:>5} files  ->  {forged_dir}")
    print(f"  masks/    : {counts['masks']:>5} files  ->  {masks_dir}")
    if counts["skipped"]:
        print(f"  skipped   : {counts['skipped']:>5} files (not _B / _F / _M)")

    # Sanity checks
    if counts["forged"] == 0:
        print("\n[WARNING] No forged (*_F) images found.")
        print("  Check that --src points to the right folder and the files")
        print("  follow the CoMoFoD naming convention (*_F.png, *_B.png, *_M.png).")
    elif counts["forged"] != counts["masks"]:
        print(f"\n[WARNING] Forged count ({counts['forged']}) != "
              f"mask count ({counts['masks']}). Some masks may be missing.")
    else:
        print("\n[OK] Forged and mask counts match -- dataset looks complete.")

    print("\nUpdate config.py (Kaggle version) with:")
    print(f"  COMOFOD_ORIGINAL = '{original_dir}'")
    print(f"  COMOFOD_FORGED   = '{forged_dir}'")
    print(f"  COMOFOD_MASKS    = '{masks_dir}'")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Organise flat CoMoFoD into project subfolders")
    p.add_argument("--src",     required=True,
                   help="Path to the raw CoMoFoD folder on Kaggle "
                        "(e.g. /kaggle/input/comofod/comofod_small)")
    p.add_argument("--dst",     default="/kaggle/working/data/comofod",
                   help="Destination base folder (default: /kaggle/working/data/comofod)")
    p.add_argument("--dry-run", action="store_true",
                   help="Print what would be copied without actually doing it")
    args = p.parse_args()
    setup(args.src, args.dst, dry_run=args.dry_run)
