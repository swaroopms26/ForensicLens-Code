"""
scripts/compression_sweep.py — Controlled JPEG Recompression Sweep Experiment
===============================================================================
Isolates the effect of JPEG compression history on ELA-based tampering
localization, holding image content, manipulation, and ground-truth mask
constant across conditions.

Experimental design (paired):
  - "uncompressed": original PNG/BMP/TIF file from CoMoFoD forged set
  - "q90" / "q70" / "q50": the *same* image re-saved as JPEG at quality
    90, 70, 50 respectively, then fed through the same ELA pipeline.

ELA quality is held constant at config.ELA_QUALITY (90) for ALL conditions,
so any metric change is attributable solely to input compression history.

Outputs
-------
  results/compression_sweep_summary.json   — per-image arrays + aggregate stats
  results/compression_sweep_iou.pdf        — high-quality vector plot
  results/compression_sweep_iou.png        — raster version for web/presentations
  Console table of mean IoU [95 CI] per condition x backbone

Usage
-----
  # Run from the project root:
  python scripts/compression_sweep.py [--n-images 100] [--seed 42] [--n-bootstrap 2000]

Notes
-----
  * No training is performed; both segmentation models run in eval / no_grad.
  * Monotonicity is NOT assumed or enforced — the script reports whatever the
    data show.  Heavy compression can destroy ELA cues and produce non-monotonic
    results across backbones and images.
  * DataParallel `module.` checkpoint prefixes are stripped automatically.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

# ── Make the project root importable regardless of CWD ───────────────────────
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import random
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageFile

ImageFile.LOAD_TRUNCATED_IMAGES = True

# ── Project imports ───────────────────────────────────────────────────────────
import config
from core.ela import ela_transform
from core.segmentation import VGG16_UNet, ResNet50_UNet

# ── Constants ─────────────────────────────────────────────────────────────────
LOSSLESS_EXTS  = {".png", ".bmp", ".tif", ".tiff"}
CONDITIONS     = ["uncompressed", "q90", "q70", "q50"]
JPEG_QUALITIES = {"q90": 90, "q70": 70, "q50": 50}
BACKBONES      = ["vgg16", "resnet50"]


# ─────────────────────────────────────────────────────────────────────────────
# Section 1 — Source-data collection
# ─────────────────────────────────────────────────────────────────────────────

def _find_mask_for_forged(forged_path: Path, mask_dir: Path):
    """
    Resolve the CoMoFoD mask for a given forged image.

    CoMoFoD naming convention:
        forged  :  NNN_F[suffix].png   (e.g. 001_F.png, 001_F_BC1.png)
        mask    :  NNN_B.png

    The prefix (the three-digit number) is extracted from the stem and used
    to find <prefix>_B.png in the mask directory.
    """
    stem   = forged_path.stem          # e.g. "001_F" or "001_F_BC1"
    prefix = stem.split("_")[0]        # "001"

    # Primary: <prefix>_B.png
    candidate = mask_dir / f"{prefix}_B.png"
    if candidate.exists():
        return candidate

    # Fallback: <prefix>_B.bmp / .tif
    for ext in (".bmp", ".tif", ".tiff"):
        candidate = mask_dir / f"{prefix}_B{ext}"
        if candidate.exists():
            return candidate

    return None


def collect_lossless_pairs(forged_dir: Path, mask_dir: Path, n: int, seed: int):
    """
    Collect up to *n* (forged_image, mask) pairs where:
      - the forged image is in a lossless format (png/bmp/tif)
      - a matching mask exists

    Returns a random sample of exactly min(n, available) pairs.
    """
    rng = random.Random(seed)

    all_forged = sorted(forged_dir.iterdir())
    candidates = []

    skipped_lossy   = 0
    skipped_no_mask = 0

    for fpath in all_forged:
        if not fpath.is_file():
            continue
        if fpath.suffix.lower() not in LOSSLESS_EXTS:
            skipped_lossy += 1
            continue
        mpath = _find_mask_for_forged(fpath, mask_dir)
        if mpath is None:
            skipped_no_mask += 1
            continue
        candidates.append((fpath, mpath))

    print(f"[collect] Total lossless forged images  : {len(candidates)}")
    print(f"[collect] Skipped (JPEG / lossy source) : {skipped_lossy}")
    print(f"[collect] Skipped (mask not found)      : {skipped_no_mask}")

    if not candidates:
        raise RuntimeError(
            "No lossless (image, mask) pairs found in the CoMoFoD forged directory. "
            f"Checked: {forged_dir}"
        )

    rng.shuffle(candidates)
    sampled = candidates[:n]

    print(f"[collect] Sampling {len(sampled)} / {len(candidates)} pairs (seed={seed})")
    return sampled


# ─────────────────────────────────────────────────────────────────────────────
# Section 2 — Condition preparation
# ─────────────────────────────────────────────────────────────────────────────

def prepare_conditions(pairs, sweep_root: Path):
    """
    For each (forged, mask) pair, create condition directories and write
    JPEG-recompressed versions.  Returns a dict mapping condition name to
    a list of (image_path, mask_path) aligned with *pairs*.

    The "uncompressed" condition uses the original file path as-is.
    """
    condition_pairs = {cond: [] for cond in CONDITIONS}

    for cond in CONDITIONS:
        (sweep_root / cond).mkdir(parents=True, exist_ok=True)

    print(f"\n[prepare] Writing JPEG-compressed condition images ...")

    for forged_path, mask_path in pairs:
        # ---------- uncompressed (original lossless) ----------
        condition_pairs["uncompressed"].append((forged_path, mask_path))

        # ---------- q90 / q70 / q50 ----------
        pil_img = Image.open(str(forged_path)).convert("RGB")  # load once
        for cond, quality in JPEG_QUALITIES.items():
            out_name = forged_path.stem + ".jpg"
            out_path = sweep_root / cond / out_name
            if not out_path.exists():
                pil_img.save(str(out_path), "JPEG", quality=quality)
            condition_pairs[cond].append((out_path, mask_path))

    print(f"[prepare] Done — {len(pairs)} images x {len(CONDITIONS)} conditions.")
    return condition_pairs


# ─────────────────────────────────────────────────────────────────────────────
# Section 3 — Model loading
# ─────────────────────────────────────────────────────────────────────────────

def _strip_module_prefix(state_dict: dict) -> dict:
    """Remove 'module.' prefix injected by DataParallel wrappers."""
    new_sd = {}
    for k, v in state_dict.items():
        new_key = k[len("module."):] if k.startswith("module.") else k
        new_sd[new_key] = v
    return new_sd


def load_models():
    """
    Load VGG16_UNet and ResNet50_UNet from checkpoints defined in config.
    Both models are placed in eval() mode.  DataParallel prefixes stripped.
    """
    device  = config.DEVICE
    models  = {}

    # ── VGG16-UNet ─────────────────────────────────────────────────────
    vgg_model = VGG16_UNet().to(device)
    if os.path.exists(config.VGG16_SEG_CKPT):
        raw_sd = torch.load(config.VGG16_SEG_CKPT, map_location=device)
        sd     = _strip_module_prefix(raw_sd)
        vgg_model.load_state_dict(sd, strict=True)
        print(f"[models] VGG16_UNet   loaded  <- {config.VGG16_SEG_CKPT}")
    else:
        print(
            f"[models] WARNING: VGG16 checkpoint not found at "
            f"{config.VGG16_SEG_CKPT} — running with random weights."
        )
    vgg_model.eval()
    models["vgg16"] = vgg_model

    # ── ResNet50-UNet ───────────────────────────────────────────────────
    res_model = ResNet50_UNet().to(device)
    if os.path.exists(config.RESNET50_SEG_CKPT):
        raw_sd = torch.load(config.RESNET50_SEG_CKPT, map_location=device)
        sd     = _strip_module_prefix(raw_sd)
        res_model.load_state_dict(sd, strict=True)
        print(f"[models] ResNet50_UNet loaded  <- {config.RESNET50_SEG_CKPT}")
    else:
        print(
            f"[models] WARNING: ResNet50 checkpoint not found at "
            f"{config.RESNET50_SEG_CKPT} — running with random weights."
        )
    res_model.eval()
    models["resnet50"] = res_model

    return models


# ─────────────────────────────────────────────────────────────────────────────
# Section 4 — Per-image evaluation
# ─────────────────────────────────────────────────────────────────────────────

def _load_gt_mask(mask_path: Path, img_size):
    """
    Open ground-truth mask, resize to img_size with NEAREST interpolation,
    and binarize: pixel > 0.5 -> 1 else 0.

    Returns binary uint8 array of shape (H, W).
    """
    mask_pil = Image.open(str(mask_path)).convert("L")
    mask_pil = mask_pil.resize((img_size[1], img_size[0]), Image.NEAREST)
    mask_arr = np.array(mask_pil, dtype=np.float32) / 255.0
    return (mask_arr > 0.5).astype(np.uint8)


def compute_metrics(pred_mask: np.ndarray, gt_mask: np.ndarray):
    """
    Compute IoU (Jaccard) and Dice coefficient between two binary uint8 arrays.

    Edge case: both masks all-zero -> IoU=1, Dice=1 (perfect agreement on
    absence of forgery).
    """
    pred = pred_mask.astype(bool)
    gt   = gt_mask.astype(bool)

    intersection = np.logical_and(pred, gt).sum()
    union        = np.logical_or(pred, gt).sum()
    sum_both     = pred.sum() + gt.sum()

    if union == 0:
        iou  = 1.0
        dice = 1.0
    else:
        iou  = float(intersection) / float(union)
        dice = (2.0 * float(intersection)) / float(sum_both) if sum_both > 0 else 1.0

    return {"iou": iou, "dice": dice}


def evaluate_image(
    image_path,
    mask_path,
    models,
    device,
    img_size,
    ela_quality,
    seg_threshold,
):
    """
    Run ELA -> segmentation -> metric computation for one (image, mask) pair.

    ELA quality is FIXED (config.ELA_QUALITY = 90) for ALL conditions.

    Returns:
        {backbone_name: {"iou": float, "dice": float}}
    """
    # ── ELA preprocessing — quality constant across all conditions ────────
    ela_array = ela_transform(
        str(image_path),
        target_size=img_size,
        quality=ela_quality,
    )  # (H, W, 3) float32 in [0, 1]

    ela_tensor = (
        torch.from_numpy(ela_array)
        .permute(2, 0, 1)    # -> (3, H, W)
        .unsqueeze(0)         # -> (1, 3, H, W)
        .to(device)
    )

    # ── Ground-truth mask ─────────────────────────────────────────────────
    gt_mask = _load_gt_mask(mask_path, img_size)

    results = {}

    with torch.no_grad():
        for backbone, model in models.items():
            logit_map = model(ela_tensor)                      # (1, 1, H, W)
            prob_map  = logit_map.squeeze().cpu().numpy()      # (H, W)
            pred_mask = (prob_map >= seg_threshold).astype(np.uint8)
            results[backbone] = compute_metrics(pred_mask, gt_mask)

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Section 5 — Bootstrap statistics
# ─────────────────────────────────────────────────────────────────────────────

def bootstrap_ci(values: np.ndarray, n_resamples: int = 2000, ci: float = 0.95, seed: int = 0):
    """
    Percentile-method bootstrap confidence interval.

    Parameters
    ----------
    values       : 1-D array of per-image metric values
    n_resamples  : number of bootstrap resamples
    ci           : confidence level (e.g. 0.95 for 95%)
    seed         : NumPy random seed

    Returns
    -------
    (mean, ci_low, ci_high)
    """
    rng = np.random.default_rng(seed)
    n   = len(values)
    means = np.empty(n_resamples, dtype=np.float64)

    for i in range(n_resamples):
        idx      = rng.integers(0, n, size=n)
        means[i] = values[idx].mean()

    alpha_half = (1.0 - ci) / 2.0
    lo  = float(np.percentile(means, 100.0 * alpha_half))
    hi  = float(np.percentile(means, 100.0 * (1.0 - alpha_half)))
    return float(values.mean()), lo, hi


def compute_aggregate_stats(per_image: dict, n_bootstrap: int) -> dict:
    """
    For each condition x backbone:
      1. Bootstrap CI on absolute metric values.
      2. Bootstrap CI on paired differences vs "uncompressed".

    per_image structure:
        {condition: {backbone: {"iou": [...], "dice": [...]}}}
    """
    stats = {}

    for cond in CONDITIONS:
        stats[cond] = {}
        for backbone in BACKBONES:
            iou_vals  = np.array(per_image[cond][backbone]["iou"],  dtype=np.float64)
            dice_vals = np.array(per_image[cond][backbone]["dice"], dtype=np.float64)

            mean_iou,  lo_iou,  hi_iou  = bootstrap_ci(iou_vals,  n_bootstrap)
            mean_dice, lo_dice, hi_dice = bootstrap_ci(dice_vals, n_bootstrap)

            entry = {
                "mean_iou":  mean_iou,
                "ci95_iou":  [lo_iou,  hi_iou],
                "mean_dice": mean_dice,
                "ci95_dice": [lo_dice, hi_dice],
            }

            # Paired differences vs uncompressed baseline
            if cond != "uncompressed":
                ref_iou  = np.array(per_image["uncompressed"][backbone]["iou"],  dtype=np.float64)
                ref_dice = np.array(per_image["uncompressed"][backbone]["dice"], dtype=np.float64)
                delta_iou  = iou_vals  - ref_iou
                delta_dice = dice_vals - ref_dice

                m_diou,  lo_diou,  hi_diou  = bootstrap_ci(delta_iou,  n_bootstrap)
                m_ddice, lo_ddice, hi_ddice = bootstrap_ci(delta_dice, n_bootstrap)

                entry["delta_iou_vs_uncompressed"] = {
                    "mean": m_diou,
                    "ci95": [lo_diou, hi_diou],
                }
                entry["delta_dice_vs_uncompressed"] = {
                    "mean": m_ddice,
                    "ci95": [lo_ddice, hi_ddice],
                }

            stats[cond][backbone] = entry

    return stats


# ─────────────────────────────────────────────────────────────────────────────
# Section 6 — Console reporting
# ─────────────────────────────────────────────────────────────────────────────

def print_results_table(stats: dict) -> None:
    """Print formatted condition x backbone results table."""
    COND_LABELS = {
        "uncompressed": "Uncompressed",
        "q90":          "Q90",
        "q70":          "Q70",
        "q50":          "Q50",
    }

    header = (
        f"{'Condition':<15} {'Backbone':<10} "
        f"{'Mean IoU':>10}  {'95% CI':>18}  "
        f"{'Mean Dice':>10}  {'95% CI':>18}"
    )
    sep = "=" * len(header)

    print("\n" + sep)
    print("  CONTROLLED RECOMPRESSION SWEEP — ELA Localization Results")
    print(sep)
    print(header)
    print(sep)

    for cond in CONDITIONS:
        for backbone in BACKBONES:
            s        = stats[cond][backbone]
            cond_lbl = COND_LABELS[cond]
            iou_ci   = f"[{s['ci95_iou'][0]:.4f}, {s['ci95_iou'][1]:.4f}]"
            dice_ci  = f"[{s['ci95_dice'][0]:.4f}, {s['ci95_dice'][1]:.4f}]"
            print(
                f"{cond_lbl:<15} {backbone:<10} "
                f"{s['mean_iou']:>10.4f}  {iou_ci:>18}  "
                f"{s['mean_dice']:>10.4f}  {dice_ci:>18}"
            )

        # Paired-difference sub-rows for non-baseline conditions
        if cond != "uncompressed":
            for backbone in BACKBONES:
                s   = stats[cond][backbone]
                d   = s.get("delta_iou_vs_uncompressed", {})
                dci = f"[{d['ci95'][0]:+.4f}, {d['ci95'][1]:+.4f}]"
                print(
                    f"  {'  delta IoU vs baseline':<23} {backbone:<10} "
                    f"{d['mean']:>+10.4f}  {dci:>18}"
                )
        print()

    print(sep + "\n")


# ─────────────────────────────────────────────────────────────────────────────
# Section 6b — Vector PDF + raster PNG plot
# ─────────────────────────────────────────────────────────────────────────────

def _build_figure(stats: dict):
    """
    Build and return (fig, ax) with the IoU sweep plot.
    Called by plot_results; kept separate so the figure object can be passed
    to both the PDF and PNG savers without re-drawing.
    """
    import matplotlib.pyplot as plt
    import matplotlib.ticker as mticker

    COND_LABELS = ["Uncompressed", "Q90", "Q70", "Q50"]
    X           = np.arange(len(CONDITIONS))

    STYLE = {
        "vgg16":    {"color": "#4C72B0", "marker": "o", "label": "VGG16-UNet",    "ls": "-"},
        "resnet50": {"color": "#DD8452", "marker": "s", "label": "ResNet50-UNet", "ls": "--"},
    }

    fig, ax = plt.subplots(figsize=(8, 5))
    fig.patch.set_facecolor("#F8F9FA")
    ax.set_facecolor("#F0F2F5")

    for backbone in BACKBONES:
        means  = np.array([stats[c][backbone]["mean_iou"] for c in CONDITIONS])
        lo     = np.array([stats[c][backbone]["ci95_iou"][0] for c in CONDITIONS])
        hi     = np.array([stats[c][backbone]["ci95_iou"][1] for c in CONDITIONS])
        err_lo = means - lo
        err_hi = hi - means

        sty = STYLE[backbone]

        ax.plot(
            X, means,
            color=sty["color"], marker=sty["marker"],
            linestyle=sty["ls"], linewidth=2.0, markersize=7,
            label=sty["label"], zorder=3,
        )
        ax.fill_between(X, lo, hi, color=sty["color"], alpha=0.15, zorder=2)
        ax.errorbar(
            X, means,
            yerr=[err_lo, err_hi],
            fmt="none",
            ecolor=sty["color"], elinewidth=1.4, capsize=5, capthick=1.4,
            zorder=4,
        )

    ax.set_xticks(X)
    ax.set_xticklabels(COND_LABELS, fontsize=12)
    ax.set_xlabel("Input Compression Condition", fontsize=13, labelpad=8)
    ax.set_ylabel("Mean IoU (Jaccard Index)", fontsize=13, labelpad=8)
    ax.set_title(
        "Effect of JPEG Compression History on ELA-Based Tampering Localization\n"
        "(ELA quality fixed at 90 for all conditions  |  CoMoFoD, n<=100, seed=42)",
        fontsize=11, pad=12, weight="bold",
    )
    ax.yaxis.set_minor_locator(mticker.AutoMinorLocator(2))
    ax.grid(True, which="major", linestyle="--", linewidth=0.8, color="#CCCCCC", zorder=0)
    ax.grid(True, which="minor", linestyle=":",  linewidth=0.5, color="#DDDDDD", zorder=0)
    ax.set_xlim(-0.4, len(CONDITIONS) - 0.6)
    ax.legend(frameon=True, framealpha=0.9, edgecolor="#BBBBBB", fontsize=11, loc="best")
    ax.annotate(
        "Shaded region = bootstrap 95% CI (n=2 000 resamples, percentile method)",
        xy=(0.01, 0.02), xycoords="axes fraction",
        fontsize=8, color="#555555", style="italic",
    )
    plt.tight_layout()
    return fig, ax


def plot_results(stats: dict, pdf_path: str, png_path: str) -> None:
    """
    Save the IoU sweep figure as:
      - A true vector PDF via matplotlib's dedicated PDF backend (PdfPages).
        Every line, marker, text element, and shaded region is stored as PDF
        drawing commands — no rasterisation occurs.
      - A 200-DPI raster PNG via the Agg backend for web / presentations.
    """
    # ── 1. Vector PDF — use the pdf backend explicitly ─────────────────────
    # Importing PdfPages switches rendering through matplotlib's PDF renderer
    # (Cairo-based PostScript / PDF path), bypassing Agg entirely.
    import matplotlib
    matplotlib.use("pdf")   # vector PDF renderer — MUST be set before pyplot import
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    import matplotlib.ticker as mticker  # noqa: F401 — used inside _build_figure

    fig, _ = _build_figure(stats)
    with PdfPages(pdf_path) as pdf:
        pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)
    print(f"[plot] Saved vector PDF : {pdf_path}")

    # ── 2. Raster PNG — switch to Agg backend ─────────────────────────────
    # matplotlib.use() cannot be called twice in the same process after pyplot
    # is imported, so we drive the Agg renderer directly via the figure canvas.
    matplotlib.use("Agg")
    import importlib
    import matplotlib.pyplot as plt2
    importlib.reload(plt2)          # reload pyplot so it picks up the Agg backend

    fig2, _ = _build_figure(stats)
    fig2.savefig(png_path, format="png", bbox_inches="tight", dpi=200)
    plt2.close(fig2)
    print(f"[plot] Saved raster PNG : {png_path}")


# ─────────────────────────────────────────────────────────────────────────────
# Main orchestrator
# ─────────────────────────────────────────────────────────────────────────────

def run_sweep(n_images: int, seed: int, n_bootstrap: int) -> None:
    """
    Full experiment pipeline:
      1. Collect lossless (forged, mask) pairs from CoMoFoD.
      2. Prepare condition directories (write JPEG recompressed images).
      3. Load frozen segmentation models.
      4. Evaluate per image x condition x backbone.
      5. Compute bootstrap statistics.
      6. Print table + write JSON + write PDF/PNG.
    """
    device        = config.DEVICE
    img_size      = config.IMG_SIZE        # (H, W)
    ela_quality   = config.ELA_QUALITY     # 90 — FIXED for ALL conditions
    seg_threshold = config.SEG_THRESHOLD   # 0.55

    results_dir = Path(config.BASE_DIR) / "results"
    sweep_root  = results_dir / "compression_sweep_data"
    json_out    = results_dir / "compression_sweep_summary.json"
    pdf_out     = results_dir / "compression_sweep_iou.pdf"
    png_out     = results_dir / "compression_sweep_iou.png"

    results_dir.mkdir(parents=True, exist_ok=True)
    sweep_root.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("  ForensicLens — Compression Sweep Experiment")
    print(f"  Device         : {device}")
    print(f"  IMG_SIZE       : {img_size}")
    print(f"  ELA quality    : {ela_quality}  (held constant across ALL conditions)")
    print(f"  SEG threshold  : {seg_threshold}")
    print(f"  N images       : {n_images}  (seed={seed})")
    print(f"  N bootstrap    : {n_bootstrap}")
    print("=" * 60 + "\n")

    # ── 1. Source data ────────────────────────────────────────────────────────
    forged_dir = Path(config.COMOFOD_FORGED)
    mask_dir   = Path(config.COMOFOD_MASKS)

    if not forged_dir.exists():
        raise FileNotFoundError(
            f"CoMoFoD forged directory not found: {forged_dir}\n"
            "Set COMOFOD_FORGED in config.py to the correct path."
        )
    if not mask_dir.exists():
        raise FileNotFoundError(
            f"CoMoFoD masks directory not found: {mask_dir}\n"
            "Set COMOFOD_MASKS in config.py to the correct path."
        )

    pairs    = collect_lossless_pairs(forged_dir, mask_dir, n=n_images, seed=seed)
    actual_n = len(pairs)

    # ── 2. Prepare conditions ─────────────────────────────────────────────────
    condition_pairs = prepare_conditions(pairs, sweep_root)

    # ── 3. Load models ────────────────────────────────────────────────────────
    print()
    models = load_models()
    print()

    # ── 4. Evaluate ───────────────────────────────────────────────────────────
    # per_image[condition][backbone]["iou"/"dice"] = list[float] over images
    per_image = {
        cond: {bb: {"iou": [], "dice": []} for bb in BACKBONES}
        for cond in CONDITIONS
    }

    # Per-image metadata records for JSON export
    image_records = []

    print(f"[eval] Evaluating {actual_n} images x {len(CONDITIONS)} conditions ...\n")

    for img_idx, (src_fpath, src_mpath) in enumerate(pairs):
        record = {
            "image_index": img_idx,
            "source_file": str(src_fpath),
            "mask_file":   str(src_mpath),
            "conditions":  {},
        }

        for cond in CONDITIONS:
            cond_img_path, cond_mask_path = condition_pairs[cond][img_idx]

            try:
                metrics_by_backbone = evaluate_image(
                    image_path    = cond_img_path,
                    mask_path     = cond_mask_path,
                    models        = models,
                    device        = device,
                    img_size      = img_size,
                    ela_quality   = ela_quality,
                    seg_threshold = seg_threshold,
                )
            except Exception as exc:
                print(f"  [WARN] img={img_idx} cond={cond}: {exc}")
                metrics_by_backbone = {
                    bb: {"iou": float("nan"), "dice": float("nan")}
                    for bb in BACKBONES
                }

            record["conditions"][cond] = {}
            for backbone in BACKBONES:
                m = metrics_by_backbone[backbone]
                per_image[cond][backbone]["iou"].append(m["iou"])
                per_image[cond][backbone]["dice"].append(m["dice"])
                record["conditions"][cond][backbone] = m

        image_records.append(record)

        # Progress report every 10 images
        if (img_idx + 1) % 10 == 0 or (img_idx + 1) == actual_n:
            for bb in BACKBONES:
                vals   = [v for v in per_image["uncompressed"][bb]["iou"] if not np.isnan(v)]
                mean_v = np.mean(vals) if vals else 0.0
                print(
                    f"  [{img_idx+1:>4}/{actual_n}] uncompressed/{bb} "
                    f"running mean IoU = {mean_v:.4f}"
                )

    # ── 5. Statistics ─────────────────────────────────────────────────────────
    # Drop NaN entries before aggregation (images that errored)
    for cond in CONDITIONS:
        for bb in BACKBONES:
            iou_arr  = np.array(per_image[cond][bb]["iou"])
            dice_arr = np.array(per_image[cond][bb]["dice"])
            valid    = ~np.isnan(iou_arr) & ~np.isnan(dice_arr)
            per_image[cond][bb]["iou"]  = iou_arr[valid].tolist()
            per_image[cond][bb]["dice"] = dice_arr[valid].tolist()

    print(f"\n[stats] Computing bootstrap CIs ({n_bootstrap} resamples) ...")
    stats = compute_aggregate_stats(per_image, n_bootstrap=n_bootstrap)

    # ── 6. Print table ────────────────────────────────────────────────────────
    print_results_table(stats)

    # ── 6a. Save JSON ─────────────────────────────────────────────────────────
    output_payload = {
        "experiment": {
            "n_images_requested":  n_images,
            "n_images_evaluated":  actual_n,
            "random_seed":         seed,
            "n_bootstrap":         n_bootstrap,
            "ela_quality_fixed":   ela_quality,
            "seg_threshold":       seg_threshold,
            "img_size":            list(img_size),
            "device":              device,
            "conditions":          CONDITIONS,
            "backbones":           BACKBONES,
            "comofod_forged_dir":  str(forged_dir),
            "comofod_masks_dir":   str(mask_dir),
        },
        "aggregate_stats":   stats,
        "per_image_arrays":  per_image,
        "per_image_records": image_records,
    }

    with open(str(json_out), "w", encoding="utf-8") as fh:
        json.dump(output_payload, fh, indent=2)
    print(f"[output] JSON summary saved : {json_out}")

    # ── 6b. Plot ──────────────────────────────────────────────────────────────
    plot_results(stats, pdf_path=str(pdf_out), png_path=str(png_out))

    print(f"\n[done] Experiment complete.\n")
    print(f"  Summary JSON : {json_out}")
    print(f"  PDF plot     : {pdf_out}")
    print(f"  PNG plot     : {png_out}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────────────────────────

def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Controlled JPEG recompression sweep — measures how JPEG compression "
            "history (independent of image content or manipulation) affects "
            "ELA-based tampering localization by VGG16-UNet and ResNet50-UNet."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument(
        "--n-images",
        type=int,
        default=100,
        help="Number of (image, mask) pairs to sample from CoMoFoD.",
    )
    p.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducible sampling of CoMoFoD pairs.",
    )
    p.add_argument(
        "--n-bootstrap",
        type=int,
        default=2000,
        help="Number of bootstrap resamples for 95%% CI estimation.",
    )
    return p


if __name__ == "__main__":
    args = _build_arg_parser().parse_args()
    run_sweep(
        n_images    = args.n_images,
        seed        = args.seed,
        n_bootstrap = args.n_bootstrap,
    )
