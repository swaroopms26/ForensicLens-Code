"""
scripts/evaluate.py — Publication-grade multi-dataset evaluation of ForensicLens.

Generates:
  5 Essential Tables  (vector PDF + 600-dpi PNG in results new/tables/)
  5 Essential Graphs  (vector PDF + 600-dpi PNG in results new/)
  Qualitative Grids   (vector PDF + 600-dpi PNG in results new/qualitative/)
  Full JSON summary   (results new/eval_summary.json)

Tests on THREE datasets:
  1. CASIA v2.0  — Primary benchmark: evaluated ONLY on the held-out 20% test split
                   (same split as training scripts, seed=SPLIT_SEED)
  2. CoMoFoD     — Cross-dataset (copy-move, WITH pixel masks, 512x512) — full set
  3. Columbia    — Cross-dataset (image splicing, WITH pixel masks) — full set

Output files → results new/
  eval_summary.json
  confusion_matrix_casia.png / _comofod.png / _columbia.png
  roc_curve_casia.png
  roc_curves_combined.png
  pr_curves_combined.png
  backbone_comparison_casia.png / _comofod.png / _columbia.png
  tables/table1_classification.png .. table5_efficiency.png
  qualitative/grid_success_casia.png
  qualitative/grid_crossdomain_comofod.png
  qualitative/grid_failure_cases.png

Usage
-----
    python scripts/evaluate.py [--split 0.20]
"""

import argparse
import json
import os
import sys
import time

import matplotlib
matplotlib.use("pdf")       # vector PDF backend — must be set before importing pyplot
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score, roc_curve,
    precision_recall_curve, average_precision_score,
)
from torch.utils.data import DataLoader, random_split

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config import (
    BATCH_SIZE, DEVICE, IMG_SIZE, VAL_SPLIT, TEST_SPLIT, SPLIT_SEED,
    CLASSIFIER_CKPT, VGG16_SEG_CKPT, RESNET50_SEG_CKPT, SEG_THRESHOLD,
    # Dataset 1 — CASIA
    CASIA_AUTHENTIC, CASIA_TAMPERED, CASIA_MASKS,
    # Dataset 2 — CoMoFoD
    COMOFOD_ORIGINAL, COMOFOD_FORGED, COMOFOD_MASKS,
    # Dataset 3 — Columbia
    COLUMBIA_AUTHENTIC, COLUMBIA_TAMPERED, COLUMBIA_MASKS,
    # MICC (used in combined classifier dataset, same as train_classifier.py)
    MICC_AUTHENTIC, MICC_TAMPERED,
)
from core.classifier import ForgeryClassifier
from core.datasets import ForgeryDataset
from core.ela import ela_transform
from core.segmentation import ResNet50_UNet, VGG16_UNet

# ── Output directories ────────────────────────────────────────────────────────
RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results new")
TABLES_DIR  = os.path.join(RESULTS_DIR, "tables")
QUAL_DIR    = os.path.join(RESULTS_DIR, "qualitative")
for _d in (RESULTS_DIR, TABLES_DIR, QUAL_DIR):
    os.makedirs(_d, exist_ok=True)


# ── Publication-quality save helper ──────────────────────────────────────────
def save_fig(fig, stem: str, vector: bool = True, raster_dpi: int = 600):
    """Save *fig* as both a vector PDF and a 600-dpi PNG."""
    if vector:
        fig.savefig(stem + ".pdf", bbox_inches="tight")
    fig.savefig(stem + ".png", dpi=raster_dpi, bbox_inches="tight")

# ── Matplotlib defaults ───────────────────────────────────────────────────────
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 10,
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "figure.facecolor": "white",
})
COLORS = {
    "vgg16":    "#6c5ce7",
    "resnet50": "#00cec9",
    "casia":    "#e17055",
    "comofod":  "#00b894",
    "columbia": "#0984e3",
}


# ==============================================================================
#  METRIC HELPERS
# ==============================================================================

def _seg_metrics(model, loader, threshold=None):
    """Pixel-level IoU, Dice, PixelAcc, Precision, Recall, **FPR** for one model."""
    if threshold is None:
        threshold = SEG_THRESHOLD
    model.eval()
    tot_iou = tot_dice = tot_pix = tot_prec = tot_rec = tot_fpr = 0.0
    n = 0
    with torch.no_grad():
        for ela, masks in loader:
            ela, masks = ela.to(DEVICE), masks.to(DEVICE)
            pred_prob = model(ela)
            pred_bin  = (pred_prob > threshold).float()
            tgt_bin   = (masks > 0.5).float()

            inter = (pred_bin * tgt_bin).sum().item()
            union = (pred_bin + tgt_bin).clamp(0, 1).sum().item()
            fp    = (pred_bin * (1 - tgt_bin)).sum().item()
            fn    = ((1 - pred_bin) * tgt_bin).sum().item()
            tn    = ((1 - pred_bin) * (1 - tgt_bin)).sum().item()

            tot_iou  += inter / (union + 1e-6)
            tot_dice += 2 * inter / (pred_bin.sum().item() + tgt_bin.sum().item() + 1e-6)
            tot_pix  += (pred_bin == tgt_bin).float().mean().item()
            tot_prec += inter / (inter + fp + 1e-6)
            tot_rec  += inter / (inter + fn + 1e-6)
            tot_fpr  += fp / (fp + tn + 1e-6)
            n += 1

    nn = max(n, 1)
    return {
        "IoU":       round(tot_iou  / nn, 4),
        "Dice/F1":   round(tot_dice / nn, 4),
        "PixelAcc":  round(tot_pix  / nn, 4),
        "Precision": round(tot_prec / nn, 4),
        "Recall":    round(tot_rec  / nn, 4),
        "FPR":       round(tot_fpr  / nn, 4),
    }


def _count_params(model):
    """Parameter count in millions."""
    return sum(p.numel() for p in model.parameters()) / 1e6


def _measure_inference_time(model, loader, n_samples=50):
    """Average inference time in ms/image."""
    model.eval()
    times, count = [], 0
    with torch.no_grad():
        for ela, _ in loader:
            for i in range(ela.size(0)):
                if count >= n_samples:
                    break
                single = ela[i:i+1].to(DEVICE)
                t0 = time.perf_counter()
                _ = model(single)
                if DEVICE == "cuda":
                    torch.cuda.synchronize()
                times.append((time.perf_counter() - t0) * 1000)
                count += 1
            if count >= n_samples:
                break
    return round(float(np.mean(times)), 2) if times else 0.0


def eval_classifier(model, loader, label):
    """Binary classification metrics + AUC.  (RETAINED from original)"""
    model.eval()
    all_labels, all_scores = [], []
    with torch.no_grad():
        for ela, labels in loader:
            scores = model(ela.to(DEVICE)).cpu().numpy().flatten()
            all_scores.extend(scores.tolist())
            all_labels.extend(labels.numpy().flatten().tolist())

    all_preds = [int(s >= 0.5) for s in all_scores]
    acc  = accuracy_score(all_labels, all_preds)
    prec = precision_score(all_labels, all_preds, zero_division=0)
    rec  = recall_score(all_labels, all_preds, zero_division=0)
    f1   = f1_score(all_labels, all_preds, zero_division=0)
    auc  = roc_auc_score(all_labels, all_scores) if len(set(all_labels)) > 1 else 0.0

    print(f"\n── Classification: {label} ──")
    print(f"  Accuracy : {acc:.4f}   Precision: {prec:.4f}")
    print(f"  Recall   : {rec:.4f}   F1       : {f1:.4f}   AUC: {auc:.4f}")
    print(classification_report(all_labels, all_preds,
                                target_names=["Authentic", "Tampered"]))

    return {"accuracy": round(acc, 4), "precision": round(prec, 4),
            "recall":   round(rec, 4), "f1":        round(f1, 4),
            "auc":      round(auc, 4),
            "_labels": all_labels, "_scores": all_scores}


# ==============================================================================
#  PLOT HELPERS  (existing — retained + enhanced)
# ==============================================================================

def _plot_confusion_matrix(y_true, y_pred, title, stem):
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(5, 4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set(xticks=[0, 1], yticks=[0, 1],
           xticklabels=["Authentic", "Tampered"],
           yticklabels=["Authentic", "Tampered"],
           xlabel="Predicted", ylabel="True", title=title)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black",
                    fontsize=14)
    fig.colorbar(im); fig.tight_layout()
    save_fig(fig, stem)
    plt.close(fig)
    print(f"  → {stem}.pdf / .png")


def _plot_roc(y_true, y_scores, title, stem):
    fpr, tpr, _ = roc_curve(y_true, y_scores)
    auc_val = roc_auc_score(y_true, y_scores)
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.plot(fpr, tpr, lw=2, label=f"AUC = {auc_val:.4f}")
    ax.plot([0, 1], [0, 1], "k--")
    ax.set(xlabel="False Positive Rate", ylabel="True Positive Rate", title=title)
    ax.legend(); fig.tight_layout()
    save_fig(fig, stem)
    plt.close(fig)
    print(f"  → {stem}.pdf / .png")


def _plot_backbone_comparison(vgg_m, res_m, title, stem):
    metrics = list(vgg_m.keys())
    x = np.arange(len(metrics))
    fig, ax = plt.subplots(figsize=(9, 4))
    b1 = ax.bar(x - 0.2, [vgg_m[m] for m in metrics], 0.4,
                label="VGG16-UNet",    color=COLORS["vgg16"])
    b2 = ax.bar(x + 0.2, [res_m[m] for m in metrics], 0.4,
                label="ResNet50-UNet", color=COLORS["resnet50"])
    ax.set(xticks=x, xticklabels=metrics, ylim=(0, 1.08),
           ylabel="Score", title=title)
    ax.legend()
    for bar in [*b1, *b2]:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                f"{bar.get_height():.3f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    save_fig(fig, stem)
    plt.close(fig)
    print(f"  → {stem}.pdf / .png")


# ==============================================================================
#  NEW PLOT HELPERS
# ==============================================================================

def _plot_combined_roc(roc_data, stem):
    """All datasets' ROC curves on one figure."""
    fig, ax = plt.subplots(figsize=(7, 5))
    for ds_name, (labels, scores) in roc_data.items():
        if len(set(labels)) < 2:
            continue
        fpr, tpr, _ = roc_curve(labels, scores)
        auc_val = roc_auc_score(labels, scores)
        ckey = ds_name.lower().split()[0]
        ax.plot(fpr, tpr, lw=2, label=f"{ds_name} (AUC={auc_val:.4f})",
                color=COLORS.get(ckey, "#636e72"))
    ax.plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5)
    ax.set(xlabel="False Positive Rate", ylabel="True Positive Rate",
           title="ROC Curves - Cross-Domain Classification")
    ax.legend(loc="lower right"); ax.grid(True, alpha=0.3)
    fig.tight_layout()
    save_fig(fig, stem)
    plt.close(fig)
    print(f"  → {stem}.pdf / .png")


def _plot_combined_pr(pr_data, stem):
    """All datasets' Precision-Recall curves on one figure."""
    fig, ax = plt.subplots(figsize=(7, 5))
    for ds_name, (labels, scores) in pr_data.items():
        if len(set(labels)) < 2:
            continue
        prec_arr, rec_arr, _ = precision_recall_curve(labels, scores)
        ap = average_precision_score(labels, scores)
        ckey = ds_name.lower().split()[0]
        ax.plot(rec_arr, prec_arr, lw=2, label=f"{ds_name} (AP={ap:.4f})",
                color=COLORS.get(ckey, "#636e72"))
    ax.set(xlabel="Recall", ylabel="Precision",
           title="Precision-Recall Curves - Cross-Domain Classification")
    ax.legend(loc="lower left"); ax.grid(True, alpha=0.3)
    fig.tight_layout()
    save_fig(fig, stem)
    plt.close(fig)
    print(f"  → {stem}.pdf / .png")


def _plot_training_convergence(stem):
    """Plot training convergence if log JSONs exist, else print a note."""
    log_vgg = os.path.join(RESULTS_DIR, "training_log_vgg16.json")
    log_res = os.path.join(RESULTS_DIR, "training_log_resnet50.json")
    if not (os.path.exists(log_vgg) or os.path.exists(log_res)):
        print("  [Skip] No training log files found (training_log_vgg16.json / "
              "training_log_resnet50.json).")
        print("         Export epoch-level metrics from Kaggle to generate this plot.")
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    for log_path, name, color in [(log_vgg, "VGG16", COLORS["vgg16"]),
                                   (log_res, "ResNet50", COLORS["resnet50"])]:
        if not os.path.exists(log_path):
            continue
        with open(log_path) as f:
            data = json.load(f)
        epochs = list(range(1, len(data.get("train_loss", [])) + 1))
        if "train_loss" in data:
            ax1.plot(epochs, data["train_loss"], "-", color=color, alpha=0.6,
                     label=f"{name} Train")
        if "val_loss" in data:
            ax1.plot(epochs, data["val_loss"], "--", color=color,
                     label=f"{name} Val")
        if "val_iou" in data:
            ax2.plot(epochs, data["val_iou"], "-", color=color,
                     label=f"{name} Val IoU")

    ax1.set(xlabel="Epoch", ylabel="Loss", title="Training & Validation Loss")
    ax1.legend(); ax1.grid(True, alpha=0.3)
    ax2.set(xlabel="Epoch", ylabel="IoU", title="Validation IoU")
    ax2.legend(); ax2.grid(True, alpha=0.3)
    fig.suptitle("Training Convergence", fontsize=14, fontweight="bold")
    fig.tight_layout()
    save_fig(fig, stem)
    plt.close(fig)
    print(f"  → {stem}.pdf / .png")


def _render_table_image(headers, rows, title, stem):
    """Render a formatted data table as both a vector PDF and 600-dpi PNG."""
    n_cols = len(headers)
    n_rows = len(rows)
    fig_w = max(10, n_cols * 2.0)
    fig_h = max(2.5, (n_rows + 2) * 0.5)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    ax.axis("off")
    ax.set_title(title, fontsize=13, fontweight="bold", pad=20)
    table = ax.table(cellText=rows, colLabels=headers, cellLoc="center", loc="center")
    table.auto_set_font_size(False); table.set_fontsize(9); table.scale(1.0, 1.6)
    # Style header row
    for j in range(n_cols):
        table[0, j].set_facecolor("#2d3436")
        table[0, j].set_text_props(color="white", fontweight="bold")
    # Alternate row shading
    for i in range(1, n_rows + 1):
        for j in range(n_cols):
            table[i, j].set_facecolor("#f5f6fa" if i % 2 == 0 else "white")
    fig.tight_layout()
    save_fig(fig, stem)
    plt.close(fig)
    print(f"  → {stem}.pdf / .png")


def _plot_qualitative_grid(samples, vgg_model, res_model, title, path):
    """5-row grid: Input | ELA | Ground Truth | VGG16 Pred | ResNet50 Pred."""
    n = min(len(samples), 3)
    if n == 0:
        print(f"  [Skip] No samples for: {title}")
        return
    fig, axes = plt.subplots(5, n, figsize=(4 * n, 16))
    if n == 1:
        axes = axes.reshape(-1, 1)

    row_labels = ["Input Image", "ELA Map", "Ground Truth",
                  "VGG16 Prediction", "ResNet50 Prediction"]
    vgg_model.eval(); res_model.eval()

    for col, sample in enumerate(samples[:n]):
        img_path  = sample["img_path"]
        mask_path = sample.get("mask_path")
        # Row 0: original
        try:
            orig = Image.open(img_path).convert("RGB").resize(IMG_SIZE)
            axes[0, col].imshow(np.array(orig))
        except Exception:
            axes[0, col].text(0.5, 0.5, "Load Error", ha="center", va="center")
        axes[0, col].set_title(os.path.basename(img_path)[:25], fontsize=7)
        # Row 1: ELA
        try:
            ela_arr = ela_transform(img_path, target_size=IMG_SIZE)
            axes[1, col].imshow(ela_arr)
        except Exception:
            axes[1, col].text(0.5, 0.5, "ELA Error", ha="center", va="center")
        # Row 2: ground truth
        if mask_path and os.path.exists(mask_path):
            try:
                gt = Image.open(mask_path).convert("L").resize(IMG_SIZE)
                axes[2, col].imshow(np.array(gt), cmap="gray")
            except Exception:
                axes[2, col].text(0.5, 0.5, "Mask Error", ha="center", va="center")
        else:
            axes[2, col].text(0.5, 0.5, "No Mask", ha="center", va="center",
                              transform=axes[2, col].transAxes)
        # Row 3-4: model predictions
        try:
            ela_t = torch.from_numpy(ela_arr).permute(2, 0, 1).unsqueeze(0).to(DEVICE)
            with torch.no_grad():
                vp = vgg_model(ela_t).cpu().squeeze().numpy()
                rp = res_model(ela_t).cpu().squeeze().numpy()
            axes[3, col].imshow(vp, cmap="hot", vmin=0, vmax=1)
            axes[4, col].imshow(rp, cmap="hot", vmin=0, vmax=1)
        except Exception:
            axes[3, col].text(0.5, 0.5, "Error", ha="center", va="center")
            axes[4, col].text(0.5, 0.5, "Error", ha="center", va="center")

    for row, lbl in enumerate(row_labels):
        axes[row, 0].set_ylabel(lbl, fontsize=10, fontweight="bold")
    for ax in axes.flat:
        ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle(title, fontsize=14, fontweight="bold", y=1.01)
    fig.tight_layout()
    # Qualitative grids contain photos so vector=False; still saved as 600-dpi PNG
    save_fig(fig, path, vector=False, raster_dpi=600)
    plt.close(fig)
    print(f"  → {path}.png")


# ==============================================================================
#  SEGMENTATION DRIVER (runs both backbones, returns models for reuse)
# ==============================================================================

def _load_seg_model(name, ckpt, ModelCls):
    """Load a segmentation model, return (model, param_count_M)."""
    model = ModelCls().to(DEVICE)
    if os.path.exists(ckpt):
        state = torch.load(ckpt, map_location=DEVICE)
        if any(k.startswith("module.") for k in state):
            state = {k.replace("module.", ""): v for k, v in state.items()}
        model.load_state_dict(state)
        print(f"  [{name}] Loaded: {ckpt}")
    else:
        print(f"  [{name}] ⚠ Checkpoint missing: {ckpt} (untrained weights)")
    return model


def _run_seg_eval(seg_loader, label, chart_suffix, summary):
    """Evaluate BOTH backbones; return (vgg_metrics, res_metrics, {name: model})."""
    BACKBONES = [
        ("VGG16-UNet",    VGG16_SEG_CKPT,    VGG16_UNet),
        ("ResNet50-UNet", RESNET50_SEG_CKPT, ResNet50_UNet),
    ]
    vgg_m = res_m = {}
    models = {}
    for name, ckpt, Cls in BACKBONES:
        model = _load_seg_model(name, ckpt, Cls)
        models[name] = model
        metrics = _seg_metrics(model, seg_loader)
        metrics["Params(M)"]   = round(_count_params(model), 1)
        metrics["InfTime(ms)"] = _measure_inference_time(model, seg_loader)
        print(f"  [{name}] {label}: {metrics}")
        if "VGG16" in name:
            vgg_m = metrics
        else:
            res_m = metrics

    key = f"segmentation_{chart_suffix}"
    summary[key] = {"VGG16-UNet": vgg_m, "ResNet50-UNet": res_m}

    # Backbone comparison bar chart (RETAINED)
    if vgg_m and res_m:
        plot_keys = [k for k in vgg_m if k not in ("Params(M)", "InfTime(ms)")]
        _plot_backbone_comparison(
            {k: vgg_m[k] for k in plot_keys},
            {k: res_m[k] for k in plot_keys},
            f"Backbone Comparison — {label}",
            os.path.join(RESULTS_DIR, f"backbone_comparison_{chart_suffix}"),
        )
    return vgg_m, res_m, models


# ==============================================================================
#  MAIN
# ==============================================================================

def main():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()

    summary       = {}
    cls_roc_data  = {}      # {dataset_name: (labels, scores)}
    cls_pr_data   = {}

    # ── Load classifier ───────────────────────────────────────────────────────
    clf = ForgeryClassifier(input_size=IMG_SIZE).to(DEVICE)
    if os.path.exists(CLASSIFIER_CKPT):
        clf.load_state_dict(torch.load(CLASSIFIER_CKPT, map_location=DEVICE))
        print(f"[Classifier] Loaded: {CLASSIFIER_CKPT}")
    else:
        print("[Classifier] ⚠ Checkpoint not found — using untrained weights.")
    clf.eval()
    summary["classifier_params_M"] = round(_count_params(clf), 1)

    # ══════════════════════════════════════════════════════════════════════════
    # DATASET 1 — CASIA v2.0
    # ══════════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 60)
    print("  CASIA v2.0 — Primary Benchmark (20 % held-out test split only)")
    print("=" * 60)

    # ── Classification: build the SAME combined CASIA+MICC dataset as
    # train_classifier.py (same order + same seed) so the test indices match.
    casia_cls_full = ForgeryDataset(
        authentic_dir=CASIA_AUTHENTIC, tampered_dir=CASIA_TAMPERED,
        mask_dir=None, phase="classification", img_size=IMG_SIZE)
    if os.path.isdir(MICC_AUTHENTIC) or os.path.isdir(MICC_TAMPERED):
        micc_ds = ForgeryDataset(
            authentic_dir=MICC_AUTHENTIC, tampered_dir=MICC_TAMPERED,
            mask_dir=None, phase="classification", img_size=IMG_SIZE)
        casia_cls_full.samples.extend(micc_ds.samples)

    n_test_cls  = int(len(casia_cls_full) * TEST_SPLIT)
    n_val_cls   = int(len(casia_cls_full) * VAL_SPLIT)
    n_train_cls = len(casia_cls_full) - n_val_cls - n_test_cls
    _, _, casia_test_ds = random_split(
        casia_cls_full, [n_train_cls, n_val_cls, n_test_cls],
        generator=torch.Generator().manual_seed(SPLIT_SEED),
    )
    # Keep only CASIA samples (exclude MICC samples from CASIA metrics)
    casia_dirs = (
        os.path.realpath(CASIA_AUTHENTIC) if os.path.isdir(CASIA_AUTHENTIC) else "",
        os.path.realpath(CASIA_TAMPERED)  if os.path.isdir(CASIA_TAMPERED)  else "",
    )
    casia_test_samples = [
        casia_cls_full.samples[i] for i in casia_test_ds.indices
        if any(os.path.realpath(casia_cls_full.samples[i]["img_path"]).startswith(d)
               for d in casia_dirs if d)
    ]
    print(f"[CASIA Cls] Test images used: {len(casia_test_samples)} "
          f"(of {len(casia_test_ds)} total test, MICC excluded)")

    # Build a lightweight wrapper dataset from the filtered samples
    class _SampleDS(torch.utils.data.Dataset):
        def __init__(self, parent_ds, samples):
            self._parent = parent_ds
            self._samples = samples
        def __len__(self):
            return len(self._samples)
        def __getitem__(self, idx):
            # Re-use parent's __getitem__ by temporarily swapping samples
            old = self._parent.samples
            self._parent.samples = self._samples
            item = self._parent[idx]
            self._parent.samples = old
            return item

    casia_cls_test_ds = _SampleDS(casia_cls_full, casia_test_samples)
    casia_loader = DataLoader(casia_cls_test_ds, batch_size=BATCH_SIZE,
                              shuffle=False, num_workers=0)

    # Classifier inference time
    summary["classifier_inference_ms"] = _measure_inference_time(clf, casia_loader)

    casia_cls = eval_classifier(clf, casia_loader, "CASIA v2.0")
    summary["casia_classification"] = {k: v for k, v in casia_cls.items()
                                        if not k.startswith("_")}
    cls_roc_data["CASIA v2.0"] = (casia_cls["_labels"], casia_cls["_scores"])
    cls_pr_data["CASIA v2.0"]  = (casia_cls["_labels"], casia_cls["_scores"])

    # Plots
    _plot_confusion_matrix(
        casia_cls["_labels"], [int(s >= 0.5) for s in casia_cls["_scores"]],
        "CASIA v2.0 — Confusion Matrix",
        os.path.join(RESULTS_DIR, "confusion_matrix_casia"))
    _plot_roc(
        casia_cls["_labels"], casia_cls["_scores"],
        "CASIA v2.0 — ROC Curve",
        os.path.join(RESULTS_DIR, "roc_curve_casia"))

    # ── Segmentation: same 3-way split (seed SPLIT_SEED); evaluate on test 20% only.
    casia_seg_full = ForgeryDataset(
        authentic_dir=None, tampered_dir=CASIA_TAMPERED,
        mask_dir=CASIA_MASKS, phase="segmentation", img_size=IMG_SIZE)
    n_test_seg  = int(len(casia_seg_full) * TEST_SPLIT)
    n_val_seg   = int(len(casia_seg_full) * VAL_SPLIT)
    n_train_seg = len(casia_seg_full) - n_val_seg - n_test_seg
    _, _, casia_seg_test = random_split(
        casia_seg_full, [n_train_seg, n_val_seg, n_test_seg],
        generator=torch.Generator().manual_seed(SPLIT_SEED),
    )
    print(f"[CASIA Seg] Test images used: {len(casia_seg_test)}")
    casia_seg_loader = DataLoader(casia_seg_test, batch_size=BATCH_SIZE,
                                  shuffle=False, num_workers=0)
    print("\n── Segmentation: CASIA v2.0 ──")
    casia_vgg, casia_res, casia_models = _run_seg_eval(
        casia_seg_loader, "CASIA v2.0", "casia", summary)

    # ══════════════════════════════════════════════════════════════════════════
    # DATASET 2 — CoMoFoD Small
    # ══════════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 60)
    print("  CoMoFoD Small — Cross-Dataset Benchmark (Copy-Move)")
    print("=" * 60)

    cmf_models = {}
    if os.path.isdir(COMOFOD_FORGED):
        cmf_cls_ds = ForgeryDataset(
            authentic_dir=COMOFOD_ORIGINAL, tampered_dir=COMOFOD_FORGED,
            mask_dir=None, phase="classification", img_size=IMG_SIZE)
        cmf_cls_loader = DataLoader(cmf_cls_ds, batch_size=BATCH_SIZE,
                                     shuffle=False, num_workers=0)
        cmf_cls = eval_classifier(clf, cmf_cls_loader, "CoMoFoD")
        summary["comofod_classification"] = {k: v for k, v in cmf_cls.items()
                                              if not k.startswith("_")}
        cls_roc_data["CoMoFoD"] = (cmf_cls["_labels"], cmf_cls["_scores"])
        cls_pr_data["CoMoFoD"]  = (cmf_cls["_labels"], cmf_cls["_scores"])
        _plot_confusion_matrix(
            cmf_cls["_labels"], [int(s >= 0.5) for s in cmf_cls["_scores"]],
            "CoMoFoD — Confusion Matrix",
            os.path.join(RESULTS_DIR, "confusion_matrix_comofod"))

        if os.path.isdir(COMOFOD_MASKS):
            cmf_seg_ds = ForgeryDataset(
                authentic_dir=None, tampered_dir=COMOFOD_FORGED,
                mask_dir=COMOFOD_MASKS, phase="segmentation", img_size=IMG_SIZE)
            cmf_seg_loader = DataLoader(cmf_seg_ds, batch_size=BATCH_SIZE,
                                         shuffle=False, num_workers=0)
            print("\n── Segmentation: CoMoFoD ──")
            _, _, cmf_models = _run_seg_eval(cmf_seg_loader, "CoMoFoD",
                                              "comofod", summary)
        else:
            print("  ⚠ CoMoFoD masks not found — skipping segmentation.")
    else:
        print("  ⚠ CoMoFoD not found. Place dataset in data/comofod/")

    # ══════════════════════════════════════════════════════════════════════════
    # DATASET 3 — Columbia
    # ══════════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 60)
    print("  Columbia — Cross-Dataset Benchmark (Image Splicing)")
    print("=" * 60)

    col_models = {}
    if os.path.isdir(COLUMBIA_TAMPERED):
        col_cls_ds = ForgeryDataset(
            authentic_dir=COLUMBIA_AUTHENTIC, tampered_dir=COLUMBIA_TAMPERED,
            mask_dir=None, phase="classification", img_size=IMG_SIZE)
        col_cls_loader = DataLoader(col_cls_ds, batch_size=BATCH_SIZE,
                                     shuffle=False, num_workers=0)
        col_cls = eval_classifier(clf, col_cls_loader, "Columbia")
        summary["columbia_classification"] = {k: v for k, v in col_cls.items()
                                               if not k.startswith("_")}
        cls_roc_data["Columbia"] = (col_cls["_labels"], col_cls["_scores"])
        cls_pr_data["Columbia"]  = (col_cls["_labels"], col_cls["_scores"])
        _plot_confusion_matrix(
            col_cls["_labels"], [int(s >= 0.5) for s in col_cls["_scores"]],
            "Columbia — Confusion Matrix",
            os.path.join(RESULTS_DIR, "confusion_matrix_columbia"))

        if os.path.isdir(COLUMBIA_MASKS):
            col_seg_ds = ForgeryDataset(
                authentic_dir=None, tampered_dir=COLUMBIA_TAMPERED,
                mask_dir=COLUMBIA_MASKS, phase="segmentation", img_size=IMG_SIZE)
            col_seg_loader = DataLoader(col_seg_ds, batch_size=BATCH_SIZE,
                                         shuffle=False, num_workers=0)
            print("\n── Segmentation: Columbia ──")
            _, _, col_models = _run_seg_eval(col_seg_loader, "Columbia",
                                              "columbia", summary)
        else:
            print("  ⚠ Columbia masks not found — skipping segmentation.")
    else:
        print("  ⚠ Columbia not found. Run: python scripts/download_data.py")

    # ══════════════════════════════════════════════════════════════════════════
    # COMBINED PLOTS  (NEW)
    # ══════════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 60)
    print("  Generating Combined Plots")
    print("=" * 60)

    if cls_roc_data:
        _plot_combined_roc(cls_roc_data,
                           os.path.join(RESULTS_DIR, "roc_curves_combined"))
    if cls_pr_data:
        _plot_combined_pr(cls_pr_data,
                          os.path.join(RESULTS_DIR, "pr_curves_combined"))

    # Training convergence (requires exported logs)
    _plot_training_convergence(
        os.path.join(RESULTS_DIR, "training_convergence"))

    # ══════════════════════════════════════════════════════════════════════════
    # QUALITATIVE VISUAL GRIDS  (NEW)
    # ══════════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 60)
    print("  Generating Qualitative Visual Grids")
    print("=" * 60)

    vgg_model = casia_models.get("VGG16-UNet")
    res_model = casia_models.get("ResNet50-UNet")

    if vgg_model and res_model:
        # Grid A: Success cases from CASIA
        casia_tampered_samples = [s for s in casia_seg_full.samples
                                   if s["label"] == 1.0 and s["mask_path"]]
        if casia_tampered_samples:
            rng = np.random.RandomState(42)
            idx = rng.choice(len(casia_tampered_samples),
                             min(3, len(casia_tampered_samples)), replace=False)
            _plot_qualitative_grid(
                [casia_tampered_samples[i] for i in idx], vgg_model, res_model,
                "Grid A: Success Cases (CASIA v2.0 In-Domain)",
                os.path.join(QUAL_DIR, "grid_success_casia"))

        # Grid B: Cross-domain from CoMoFoD
        if os.path.isdir(COMOFOD_FORGED) and os.path.isdir(COMOFOD_MASKS):
            cmf_full = ForgeryDataset(
                authentic_dir=COMOFOD_ORIGINAL, tampered_dir=COMOFOD_FORGED,
                mask_dir=COMOFOD_MASKS, phase="segmentation", img_size=IMG_SIZE)
            cmf_t = [s for s in cmf_full.samples
                     if s["label"] == 1.0 and s["mask_path"]]
            if cmf_t:
                rng2 = np.random.RandomState(123)
                idx2 = rng2.choice(len(cmf_t), min(3, len(cmf_t)), replace=False)
                _plot_qualitative_grid(
                    [cmf_t[i] for i in idx2], vgg_model, res_model,
                    "Grid B: Cross-Domain Challenge (CoMoFoD)",
                    os.path.join(QUAL_DIR, "grid_crossdomain_comofod"))

        # Grid C: Failure cases (lowest IoU on CASIA)
        print("  [Grid C] Identifying failure cases...")
        failures = []
        for sample in casia_tampered_samples[:100]:
            if not sample["mask_path"]:
                continue
            try:
                ela_arr = ela_transform(sample["img_path"], target_size=IMG_SIZE)
                ela_t = torch.from_numpy(ela_arr).permute(2, 0, 1).unsqueeze(0).to(DEVICE)
                gt = np.array(Image.open(sample["mask_path"]).convert("L")
                              .resize(IMG_SIZE)).astype(np.float32) / 255.0
                with torch.no_grad():
                    vp = vgg_model(ela_t).cpu().squeeze().numpy()
                    rp = res_model(ela_t).cpu().squeeze().numpy()
                vb = (vp > SEG_THRESHOLD).astype(np.float32)
                rb = (rp > SEG_THRESHOLD).astype(np.float32)
                gb = (gt > 0.5).astype(np.float32)
                viou = np.sum(vb * gb) / (np.sum(np.clip(vb + gb, 0, 1)) + 1e-6)
                riou = np.sum(rb * gb) / (np.sum(np.clip(rb + gb, 0, 1)) + 1e-6)
                failures.append(((viou + riou) / 2, sample))
            except Exception:
                continue
        failures.sort(key=lambda x: x[0])
        worst = [s for _, s in failures[:3]]
        if worst:
            _plot_qualitative_grid(
                worst, vgg_model, res_model,
                "Grid C: Failure Case Analysis",
                os.path.join(QUAL_DIR, "grid_failure_cases"))

    # ══════════════════════════════════════════════════════════════════════════
    # TABLE GENERATION  (NEW - PNG images)
    # ══════════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 60)
    print("  Generating Publication Tables")
    print("=" * 60)

    # -- Table 1: Classification Cross-Domain ----------------------------------
    t1h = ["Dataset", "Accuracy", "Precision", "Recall", "F1-Score", "AUC"]
    t1r = []
    for key, name in [("casia_classification",    "CASIA v2.0 (In-Domain)"),
                       ("comofod_classification",  "CoMoFoD (Cross-Domain)"),
                       ("columbia_classification", "Columbia (Cross-Domain)")]:
        if key in summary:
            m = summary[key]
            t1r.append([name, f"{m['accuracy']:.4f}", f"{m['precision']:.4f}",
                        f"{m['recall']:.4f}", f"{m['f1']:.4f}", f"{m['auc']:.4f}"])
    if t1r:
        _render_table_image(t1h, t1r,
            "Table 1: Classification Performance (In-Domain vs Cross-Domain)",
            os.path.join(TABLES_DIR, "table1_classification"))

    # -- Table 2: Localization Performance -------------------------------------
    t2h = ["Architecture", "Dataset", "IoU", "Dice/F1", "Pixel Acc", "FPR", "Params(M)"]
    t2r = []
    for seg_key, ds in [("segmentation_casia", "CASIA v2.0"),
                         ("segmentation_comofod", "CoMoFoD"),
                         ("segmentation_columbia", "Columbia")]:
        if seg_key in summary:
            for arch in ("VGG16-UNet", "ResNet50-UNet"):
                m = summary[seg_key].get(arch, {})
                if m:
                    t2r.append([arch, ds,
                                f"{m.get('IoU',0):.4f}", f"{m.get('Dice/F1',0):.4f}",
                                f"{m.get('PixelAcc',0):.4f}", f"{m.get('FPR',0):.4f}",
                                f"{m.get('Params(M)',0):.1f}"])
    if t2r:
        _render_table_image(t2h, t2r,
            "Table 2: Localization Performance (Backbone Comparison)",
            os.path.join(TABLES_DIR, "table2_localization"))

    # -- Table 3: Ablation Study (hardcoded from Kaggle) -----------------------
    t3h = ["Configuration", "Backbone", "Loss", "Checkpoint", "Augmentation", "Best IoU"]
    t3r = [
        ["Baseline", "VGG16",    "pos-BCE + Dice", "Val loss",              "None",  "0.4909"],
        ["Baseline", "ResNet50", "pos-BCE + Dice", "Val loss",              "None",  "0.4601"],
        ["Improved", "VGG16",    "Focal + Dice",   "IoU + threshold sweep", "Joint", "0.5597"],
        ["Improved", "ResNet50", "Focal + Dice",   "IoU + threshold sweep", "Joint", "0.6065"],
    ]
    _render_table_image(t3h, t3r,
        "Table 3: Ablation Study (Baseline vs Improved Protocol)",
        os.path.join(TABLES_DIR, "table3_ablation"))
    summary["ablation_study"] = {
        "baseline_vgg16_iou": 0.4909, "baseline_resnet50_iou": 0.4601,
        "improved_vgg16_iou": 0.5597, "improved_resnet50_iou": 0.6065,
    }

    # -- Table 4: State-of-the-Art Comparison ----------------------------------
    t4h = ["Method (Year)", "Architecture", "Dataset", "Best Metric", "Cross-Domain?"]
    t4r = [
        ["Choudhary et al. (2024)", "ELA+VGG16 U-Net",   "CASIA",              "F1: 0.777",     "No"],
        ["Satyachitra et al. (2026)","Custom CNN",         "CASIA+CoMoFoD",      "Prec: 90.18%",  "Yes"],
        ["Hao et al. (2025)",        "Vision Transformer", "CASIA+COVERAGE",     "Strong F1",     "Yes"],
        ["This Work (2026)",         "ELA+ResNet50 U-Net", "CASIA+CoMoFoD+Col.", "IoU: 0.6065",   "Yes"],
    ]
    _render_table_image(t4h, t4r,
        "Table 4: Comparison with State-of-the-Art",
        os.path.join(TABLES_DIR, "table4_sota"))

    # -- Table 5: System Efficiency --------------------------------------------
    t5h = ["Component", "Parameters (M)", "Inference (ms/img)", "Device"]
    t5r = [["Classifier (CNN)",
            f"{summary.get('classifier_params_M', 0):.1f}",
            f"{summary.get('classifier_inference_ms', 0):.1f}", DEVICE]]
    if "segmentation_casia" in summary:
        for arch in ("VGG16-UNet", "ResNet50-UNet"):
            m = summary["segmentation_casia"].get(arch, {})
            if m:
                t5r.append([arch, f"{m.get('Params(M)',0):.1f}",
                            f"{m.get('InfTime(ms)',0):.1f}", DEVICE])
    _render_table_image(t5h, t5r,
        "Table 5: System Efficiency",
        os.path.join(TABLES_DIR, "table5_efficiency"))

    # ══════════════════════════════════════════════════════════════════════════
    # CONSOLE SUMMARY TABLES  (RETAINED)
    # ══════════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 60)
    print("  Cross-Dataset Generalization Drop (Classification)")
    print("=" * 60)
    for ds_key, ds_name in [("comofod_classification", "CoMoFoD"),
                             ("columbia_classification", "Columbia")]:
        if ds_key in summary and "casia_classification" in summary:
            print(f"\n  CASIA → {ds_name}")
            for m in ("accuracy", "f1", "auc"):
                c = summary["casia_classification"].get(m, 0)
                d = summary[ds_key].get(m, 0)
                print(f"    {m:10s}  CASIA={c:.4f}  {ds_name}={d:.4f}  drop={c-d:+.4f}")

    print("\n" + "=" * 60)
    print("  Segmentation Backbone Comparison (VGG16 vs ResNet50)")
    print("=" * 60)
    for seg_key, ds_name in [("segmentation_casia",    "CASIA"),
                              ("segmentation_comofod",  "CoMoFoD"),
                              ("segmentation_columbia", "Columbia")]:
        if seg_key in summary:
            vgg_m = summary[seg_key].get("VGG16-UNet", {})
            res_m = summary[seg_key].get("ResNet50-UNet", {})
            if vgg_m and res_m:
                print(f"\n  {ds_name}:")
                for m in ("IoU", "Dice/F1", "PixelAcc", "Precision", "Recall", "FPR"):
                    if m in vgg_m and m in res_m:
                        # For FPR, lower is better
                        if m == "FPR":
                            winner = "ResNet50" if res_m[m] < vgg_m[m] else "VGG16  "
                        else:
                            winner = "ResNet50" if res_m[m] > vgg_m[m] else "VGG16  "
                        delta = abs(res_m[m] - vgg_m[m])
                        print(f"    {m:10s}  VGG16={vgg_m[m]:.4f}  ResNet50={res_m[m]:.4f}"
                              f"  → {winner} wins by {delta:.4f}")

    # -- Save full JSON --------------------------------------------------------
    out = os.path.join(RESULTS_DIR, "eval_summary.json")
    with open(out, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\n[Evaluate] Full summary saved → {out}")

    # -- Output manifest -------------------------------------------------------
    print("\n" + "=" * 60)
    print("  Output Files Generated")
    print("=" * 60)
    for root, dirs, files in os.walk(RESULTS_DIR):
        for fname in sorted(files):
            fpath = os.path.join(root, fname)
            rel   = os.path.relpath(fpath, RESULTS_DIR)
            sz    = os.path.getsize(fpath) / 1024
            print(f"  {rel:50s} ({sz:.1f} KB)")


if __name__ == "__main__":
    main()
