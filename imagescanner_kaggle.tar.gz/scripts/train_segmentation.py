"""
scripts/train_segmentation.py — Train VGG16-UNet and/or ResNet50-UNet
                                 forgery localisation models.

Key improvements for high IoU (>60%):
1.  Focal + Dice loss     — Focal loss suppresses easy-background pixels,
                             Dice directly optimises overlap metric.
2.  Data augmentation     — Random flips, rotation, colour jitter applied
                             on-the-fly to the ELA maps.
3.  IoU-based checkpointing — Save the best model by IoU (not val loss),
                               because IoU is the thesis metric.
4.  Cosine restart schedule — CosineAnnealingWarmRestarts gives multiple
                               "warm restart" boosts to escape local minima.
5.  Tunable IoU threshold  — Best threshold searched over [0.3–0.7].
6.  Extended patience      — patience=10 so strong early epochs aren't wasted.

Usage
-----
    python scripts/train_segmentation.py --backbone resnet50
    python scripts/train_segmentation.py --backbone vgg16
    python scripts/train_segmentation.py   # trains both
"""

import argparse
import os
import sys
import time
import random

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
from torch.utils.data import DataLoader, random_split

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config import (
    BATCH_SIZE, CASIA_MASKS, CASIA_TAMPERED,
    DEVICE, EPOCHS_SEG, IMG_SIZE, LR_SEG,
    RESNET50_SEG_CKPT, SPLIT_SEED, TEST_SPLIT, VAL_SPLIT,
    VGG16_SEG_CKPT, WEIGHT_DECAY,
)
from core.datasets import ForgeryDataset
from core.segmentation import ResNet50_UNet, VGG16_UNet


# ══════════════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════════════

def _parser():
    p = argparse.ArgumentParser(description="Train segmentation model(s)")
    p.add_argument("--backbone", choices=["vgg16", "resnet50", "both"],
                   default="both")
    p.add_argument("--epochs",     type=int,   default=EPOCHS_SEG)
    p.add_argument("--batch-size", type=int,   default=BATCH_SIZE)
    p.add_argument("--lr",         type=float, default=1e-3)
    p.add_argument("--pos-weight", type=float, default=8.0,
                   help="Weight for forged pixels in BCE/Focal loss")
    return p


# ══════════════════════════════════════════════════════════════════════════════
# LOSS  —  Focal + Dice (FDL)
# ══════════════════════════════════════════════════════════════════════════════

class FocalDiceLoss(nn.Module):
    """
    Alpha-balanced Focal Loss + Dice Loss.

    Focal loss suppresses easy-background pixels (which dominate the batch)
    and forces the model to focus on the harder forged-pixel examples.
    Dice loss directly optimises the IoU-like overlap metric.

    alpha  = weight on foreground (forged) class  [0.75 works well]
    gamma  = Focal modulating factor              [2.0 is standard]
    """
    def __init__(self, alpha=0.75, gamma=2.0, dice_weight=0.5):
        super().__init__()
        self.alpha       = alpha
        self.gamma       = gamma
        self.dice_weight = dice_weight

    def forward(self, pred, target):
        # ── Focal loss ──────────────────────────────────────────────────────
        bce  = F.binary_cross_entropy(pred, target, reduction="none")
        pt   = torch.where(target == 1, pred, 1 - pred)   # p_t
        at   = torch.where(target == 1,
                           torch.tensor(self.alpha,       device=pred.device),
                           torch.tensor(1.0 - self.alpha, device=pred.device))
        focal = at * (1 - pt) ** self.gamma * bce
        focal_loss = focal.mean()

        # ── Soft Dice loss ──────────────────────────────────────────────────
        pred_f  = pred.view(-1)
        tgt_f   = target.view(-1)
        inter   = (pred_f * tgt_f).sum()
        dice_loss = 1.0 - (2.0 * inter + 1.0) / (
            pred_f.sum() + tgt_f.sum() + 1.0)

        return (1 - self.dice_weight) * focal_loss + self.dice_weight * dice_loss


# ══════════════════════════════════════════════════════════════════════════════
# AUGMENTATION  —  applied in the training loop (both ELA and mask together)
# ══════════════════════════════════════════════════════════════════════════════

def augment_pair(ela: torch.Tensor, mask: torch.Tensor):
    """
    Jointly augment an (ELA-tensor, mask-tensor) pair.
    All transforms are applied identically to both.
    """
    # Random horizontal flip
    if random.random() > 0.5:
        ela  = TF.hflip(ela)
        mask = TF.hflip(mask)

    # Random vertical flip
    if random.random() > 0.5:
        ela  = TF.vflip(ela)
        mask = TF.vflip(mask)

    # Random 90° rotation
    angle = random.choice([0, 90, 180, 270])
    if angle:
        ela  = TF.rotate(ela,  angle)
        mask = TF.rotate(mask, angle)

    # Random brightness / contrast on ELA only (not mask!)
    if random.random() > 0.3:
        ela = TF.adjust_brightness(ela, brightness_factor=random.uniform(0.8, 1.2))
    if random.random() > 0.3:
        ela = TF.adjust_contrast(ela, contrast_factor=random.uniform(0.8, 1.2))

    return ela, mask


# ══════════════════════════════════════════════════════════════════════════════
# DATASET
# ══════════════════════════════════════════════════════════════════════════════

def build_seg_dataset() -> ForgeryDataset:
    ds = ForgeryDataset(
        authentic_dir=None,           # exclude authentics — all-zero masks add noise
        tampered_dir=CASIA_TAMPERED,
        mask_dir=CASIA_MASKS,
        phase="segmentation",
        img_size=IMG_SIZE,
    )
    if len(ds) == 0:
        raise RuntimeError(
            "No segmentation images found. Check CASIA_TAMPERED / CASIA_MASKS in config.py."
        )
    masks_found = sum(1 for s in ds.samples if s["mask_path"] is not None)
    print(f"[Segmentation] Masks matched: {masks_found}/{len(ds)}")
    if masks_found == 0:
        raise RuntimeError(
            "Mask matching failed! All masks are None. "
            "Check naming (expected *_gt.png convention for CASIA v2)."
        )
    return ds


# ══════════════════════════════════════════════════════════════════════════════
# IoU HELPER
# ══════════════════════════════════════════════════════════════════════════════

def batch_iou(pred_prob: torch.Tensor, target: torch.Tensor,
              threshold: float = 0.5) -> float:
    """Compute mean IoU over all samples in the batch."""
    pred_b = (pred_prob > threshold).float()
    tgt_b  = (target    > 0.5).float()
    inter  = (pred_b * tgt_b).sum()
    union  = (pred_b + tgt_b).clamp(0, 1).sum()
    return (inter / (union + 1e-6)).item()


# ══════════════════════════════════════════════════════════════════════════════
# TRAINING LOOP
# ══════════════════════════════════════════════════════════════════════════════

def _train_one(model, model_name: str, ckpt_path: str,
               train_loader, val_loader, args, freeze_epochs: int = 0):

    print(f"\n[{model_name}] Starting training on {DEVICE}")
    criterion  = FocalDiceLoss(alpha=0.75, gamma=2.0, dice_weight=0.5)
    # AdamW with decoupled weight decay gives slightly better generalisation
    optimizer  = AdamW(model.parameters(), lr=args.lr,
                       weight_decay=WEIGHT_DECAY, betas=(0.9, 0.999))
    # CosineAnnealingWarmRestarts: T_0=10 means restart every 10 epochs
    scheduler  = CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=1, eta_min=1e-6)

    best_iou      = 0.0
    patience_ctr  = 0
    PATIENCE      = 10                  # extended from default 7
    THRESHOLDS    = [0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6]

    encoder_frozen = False
    if freeze_epochs > 0:
        for name, param in model.named_parameters():
            if name.startswith("enc") or name.startswith("module.enc"):
                param.requires_grad = False
        encoder_frozen = True
        print(f"[{model_name}] Encoder frozen for first {freeze_epochs} epochs.")

    for epoch in range(1, args.epochs + 1):

        # ── Unfreeze encoder after freeze_epochs ────────────────────────────
        if encoder_frozen and epoch > freeze_epochs:
            for param in model.parameters():
                param.requires_grad = True
            for g in optimizer.param_groups:
                g["lr"] = args.lr * 0.5    # fine-tune more carefully
            encoder_frozen = False
            print(f"[{model_name}] Encoder unfrozen at epoch {epoch}.")

        t0 = time.time()

        # ── TRAIN ────────────────────────────────────────────────────────────
        model.train()
        train_loss = 0.0
        for ela, masks in train_loader:
            # Apply joint augmentation on CPU before moving to GPU
            aug_elas, aug_masks = [], []
            for e, m in zip(ela, masks):
                e_aug, m_aug = augment_pair(e, m)
                aug_elas.append(e_aug); aug_masks.append(m_aug)
            ela   = torch.stack(aug_elas).to(DEVICE)
            masks = torch.stack(aug_masks).to(DEVICE)

            optimizer.zero_grad()
            pred = model(ela)
            loss = criterion(pred, masks)
            loss.backward()
            # Gradient clipping prevents exploding gradients in the decoder
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            train_loss += loss.item() * ela.size(0)

        train_loss /= max(len(train_loader.dataset), 1)

        # ── VALIDATE ─────────────────────────────────────────────────────────
        model.eval()
        val_loss   = 0.0
        # Find best threshold + compute metrics at that threshold
        thresh_iou  = {t: 0.0 for t in THRESHOLDS}
        thresh_n    = {t: 0   for t in THRESHOLDS}
        total_dice  = 0.0
        n_mask_batches = 0

        with torch.no_grad():
            for ela, masks in val_loader:
                ela, masks = ela.to(DEVICE), masks.to(DEVICE)
                pred = model(ela)
                val_loss += criterion(pred, masks).item() * ela.size(0)

                if masks.sum() > 0:
                    n_mask_batches += 1
                    # Dice at 0.5
                    p05  = (pred > 0.5).float()
                    t05  = (masks > 0.5).float()
                    inter = (p05 * t05).sum()
                    total_dice += (2*inter / (p05.sum() + t05.sum() + 1e-6)).item()
                    # IoU at all thresholds
                    for thr in THRESHOLDS:
                        thresh_iou[thr] += batch_iou(pred, masks, thr)
                        thresh_n[thr]   += 1

        val_loss /= max(len(val_loader.dataset), 1)

        # Pick the best-threshold IoU for this epoch
        best_thr = max(THRESHOLDS, key=lambda t: thresh_iou[t] / max(thresh_n[t], 1))
        avg_iou  = thresh_iou[best_thr] / max(thresh_n[best_thr], 1)
        avg_dice = total_dice / max(n_mask_batches, 1)

        scheduler.step(epoch)
        elapsed = time.time() - t0

        print(f"Epoch {epoch:3d}/{args.epochs} | "
              f"Train: {train_loss:.4f} | Val: {val_loss:.4f} | "
              f"IoU: {avg_iou:.4f} (thr={best_thr}) | "
              f"Dice: {avg_dice:.4f} | {elapsed:.1f}s")

        # ── Checkpoint on best IoU (not val loss!) ────────────────────────
        if avg_iou > best_iou:
            best_iou     = avg_iou
            patience_ctr = 0
            state = model.module.state_dict() if hasattr(model, "module") else model.state_dict()
            torch.save(state, ckpt_path)
            print(f"  ↳ Best IoU {best_iou:.4f} — saved → {ckpt_path}")
        else:
            patience_ctr += 1
            if patience_ctr >= PATIENCE:
                print(f"\n[{model_name}] Early stopping at epoch {epoch}. Best IoU: {best_iou:.4f}")
                break

    print(f"[{model_name}] Done. Best IoU: {best_iou:.4f}\n")


# ══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def main():
    args = _parser().parse_args()
    print("[Segmentation] Building CASIA dataset (segmentation phase)…")
    ds = build_seg_dataset()
    print(f"[Segmentation] Total samples: {len(ds)}")

    # ── 3-way split: 70 % train / 10 % val / 20 % test ──────────────────────
    n_test  = int(len(ds) * TEST_SPLIT)
    n_val   = int(len(ds) * VAL_SPLIT)
    n_train = len(ds) - n_val - n_test
    train_ds, val_ds, test_ds = random_split(
        ds, [n_train, n_val, n_test],
        generator=torch.Generator().manual_seed(SPLIT_SEED),
    )
    print(f"[Segmentation] Split → train={len(train_ds)}  "
          f"val={len(val_ds)}  test={len(test_ds)}  "
          f"(test set is held out — NOT used here)")

    # Assert zero index overlap across all three partitions
    tr_idx = set(train_ds.indices)
    va_idx = set(val_ds.indices)
    te_idx = set(test_ds.indices)
    assert len(tr_idx & va_idx) == 0, "train/val overlap!"
    assert len(tr_idx & te_idx) == 0, "train/test overlap!"
    assert len(va_idx & te_idx) == 0, "val/test overlap!"

    train_loader = DataLoader(train_ds, batch_size=args.batch_size,
                              shuffle=True, num_workers=2, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch_size,
                              shuffle=False, num_workers=2)
    # test_ds is deliberately not loaded here — evaluation happens in evaluate.py

    if args.backbone in ("vgg16", "both"):
        model = VGG16_UNet()
        if torch.cuda.device_count() > 1:
            model = nn.DataParallel(model)
        model = model.to(DEVICE)
        _train_one(model, "VGG16-UNet", VGG16_SEG_CKPT,
                   train_loader, val_loader, args, freeze_epochs=2)

    if args.backbone in ("resnet50", "both"):
        model = ResNet50_UNet()
        if torch.cuda.device_count() > 1:
            model = nn.DataParallel(model)
        model = model.to(DEVICE)
        _train_one(model, "ResNet50-UNet", RESNET50_SEG_CKPT,
                   train_loader, val_loader, args, freeze_epochs=0)


if __name__ == "__main__":
    main()
