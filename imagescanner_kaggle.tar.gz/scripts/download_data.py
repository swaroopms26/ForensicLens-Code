"""
scripts/download_data.py — Download all three datasets for ForensicLens.

Datasets
--------
1. CASIA v2.0       — Primary training + evaluation dataset (classification + segmentation)
2. CoMoFoD Small    — Cross-dataset evaluation WITH pixel-level masks (copy-move, 512x512)
3. Columbia         — Cross-dataset evaluation WITH pixel-level masks (image splicing)

Usage (local)
-------------
    python scripts/download_data.py

Usage on Kaggle (run each shell line in a notebook cell with a leading !):
    !python scripts/download_data.py
"""

import os
import sys
import shutil
import zipfile


def run_cmd(cmd: str) -> bool:
    """Run a shell command, return True if it succeeded."""
    ret = os.system(cmd)
    return ret == 0


def download_kaggle(slug: str, dest_dir: str, label: str) -> bool:
    """Download and unzip a Kaggle dataset using the CLI."""
    os.makedirs(dest_dir, exist_ok=True)
    # Prefer the venv kaggle binary if available, fall through to PATH
    kaggle_bin = ".venv/Scripts/kaggle" if os.name == "nt" else ".venv/bin/kaggle"
    if not os.path.exists(kaggle_bin):
        kaggle_bin = "kaggle"
    cmd = f'{kaggle_bin} datasets download -d {slug} -p "{dest_dir}" --unzip --force'
    print(f"  ↳ Running: {cmd}")
    if run_cmd(cmd):
        print(f"  ✓ {label} downloaded successfully.")
        return True
    print(f"  ✗ Download failed for {label}. Check your kaggle.json credentials.")
    return False


def organise_comofod(dest_dir: str):
    """
    CoMoFoD Small images use a flat naming convention:
        NNN_O.png  = Original image
        NNN_F.png  = Forged (copy-move tampered) image
        NNN_B.png  = Binary mask (ground truth)
        NNN_M.png  = Coloured mask (not used for evaluation)

    This function sorts them into:
        dest_dir/original/   — *_O.png files
        dest_dir/forged/     — *_F.png files
        dest_dir/masks/      — *_B.png files
    """
    orig_dir = os.path.join(dest_dir, "original")
    forg_dir = os.path.join(dest_dir, "forged")
    mask_dir = os.path.join(dest_dir, "masks")
    for d in (orig_dir, forg_dir, mask_dir):
        os.makedirs(d, exist_ok=True)

    moved = 0
    for root, _, files in os.walk(dest_dir):
        # Skip sub-directories we just created
        if root in (orig_dir, forg_dir, mask_dir):
            continue
        for fname in files:
            src = os.path.join(root, fname)
            name_no_ext = os.path.splitext(fname)[0]
            name_lower = fname.lower()
            if not name_lower.endswith(('.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp')):
                continue

            if name_no_ext.endswith("_O"):
                shutil.move(src, os.path.join(orig_dir, fname))
                moved += 1
            elif name_no_ext.endswith("_F"):
                shutil.move(src, os.path.join(forg_dir, fname))
                moved += 1
            elif name_no_ext.endswith("_B"):
                shutil.move(src, os.path.join(mask_dir, fname))
                moved += 1
            # _M (coloured mask) files are ignored — not needed for evaluation

    if moved:
        print(f"  ↳ Organised {moved} CoMoFoD files into original/forged/masks/")
    else:
        print("  ↳ CoMoFoD files already organised (or no _O/_F/_B naming detected).")


def organise_columbia(dest_dir: str):
    """
    The Kaggle mirror (qresh/columbia-uncompressed-image-splicing-dataset or similar)
    may unzip into a flat folder.  We reorganise into:
        dest_dir/authentic/   — images that are NOT spliced (tif extension)
        dest_dir/tampered/    — images that ARE   spliced
        dest_dir/masks/       — binary ground-truth masks (edge-map images)

    COLUMBIA naming convention:
        Au_*   = authentic originals
        Tp_*   = tampered (spliced)
        edgemask_*  or *_edgemask.* = edge/binary masks for tampered images
    """
    auth_dir  = os.path.join(dest_dir, "authentic")
    tamp_dir  = os.path.join(dest_dir, "tampered")
    mask_dir  = os.path.join(dest_dir, "masks")
    for d in (auth_dir, tamp_dir, mask_dir):
        os.makedirs(d, exist_ok=True)

    moved = 0
    for root, _, files in os.walk(dest_dir):
        # Skip sub-directories we just created
        if root in (auth_dir, tamp_dir, mask_dir):
            continue
        for fname in files:
            src = os.path.join(root, fname)
            name_lower = fname.lower()
            if "edgemask" in name_lower or "mask" in name_lower:
                shutil.move(src, os.path.join(mask_dir, fname))
            elif name_lower.startswith("au_"):
                shutil.move(src, os.path.join(auth_dir, fname))
            elif name_lower.startswith("tp_"):
                shutil.move(src, os.path.join(tamp_dir, fname))
            moved += 1
    if moved:
        print(f"  ↳ Organised {moved} Columbia files into authentic/tampered/masks/")
    else:
        print("  ↳ Columbia files already organised (or no Au_/Tp_ naming detected).")


def main():
    os.makedirs("data", exist_ok=True)

    print("\n" + "="*55)
    print("  ForensicLens — Dataset Downloader")
    print("="*55)

    # ── 1. CASIA v2.0 ──────────────────────────────────────────────────────────
    print("\n[1/3] CASIA v2.0")
    casia_dir = os.path.join("data", "casia")
    if os.path.isdir(casia_dir) and any(os.scandir(casia_dir)):
        print("  ✓ Already present — skipping.")
    else:
        download_kaggle("sophatvathana/casia-dataset", casia_dir, "CASIA v2.0")

    # ── 2. CoMoFoD Small ────────────────────────────────────────────────────────
    print("\n[2/3] CoMoFoD Small (copy-move forgery, 512x512, 200 sets)")
    comofod_dir = os.path.join("data", "comofod")
    orig_dir = os.path.join(comofod_dir, "original")
    forg_dir = os.path.join(comofod_dir, "forged")
    mask_dir = os.path.join(comofod_dir, "masks")
    if os.path.isdir(forg_dir) and os.listdir(forg_dir):
        print("  ✓ Already present — skipping.")
    elif os.path.isdir(comofod_dir) and os.listdir(comofod_dir):
        # Files exist but haven't been organised yet
        print("  ↳ Found files — running organiser...")
        organise_comofod(comofod_dir)
    else:
        os.makedirs(comofod_dir, exist_ok=True)
        print("  ⚠ CoMoFoD Small not found.")
        print("    Please download manually from:")
        print("      https://www.vcl.fer.hr/comofod/comofod.html")
        print("    Then place all image files (NNN_O.png, NNN_F.png, NNN_B.png)")
        print(f"    into: {os.path.abspath(comofod_dir)}")
        print("    Re-run this script to auto-organise into original/forged/masks/")

    # ── 3. Columbia Image Splicing Dataset ──────────────────────────────────────
    print("\n[3/3] Columbia Uncompressed Image Splicing Dataset")
    columbia_dir = os.path.join("data", "columbia")
    if os.path.isdir(os.path.join(columbia_dir, "tampered")) and \
       any(os.scandir(os.path.join(columbia_dir, "tampered"))):
        print("  ✓ Already present — skipping.")
    else:
        # Primary Kaggle mirror with authentic + tampered + edge masks
        slug = "quramu/columbia-uncompressed-image-splicing-detection-dataset"
        success = download_kaggle(slug, columbia_dir, "Columbia")
        if not success:
            # Fallback mirror
            print("  ↳ Trying fallback mirror...")
            download_kaggle(
                "raufmomin/columbia-image-splicing-dataset",
                columbia_dir, "Columbia (fallback)"
            )
        organise_columbia(columbia_dir)

    print("\n" + "="*55)
    print("  All datasets ready.")
    print("="*55)


if __name__ == "__main__":
    main()
