"""
scripts/train_classifier.py — Train the ELA-based forgery classifier.

Usage
-----
    python scripts/train_classifier.py [--epochs N] [--batch-size B] [--lr LR]

Design decisions
----------------
* Combined CASIA + MICC data are used for training/validation to maximise
  sample diversity.  The test set is held out inside evaluate.py.
* CosineAnnealingLR gives a smooth warm-restart schedule that consistently
  outperforms a fixed step-LR for this small architecture.
* Early stopping (patience = EARLY_STOP) prevents overfitting; the best
  checkpoint (lowest validation loss) is saved automatically.
* Class imbalance between authentic/tampered images is handled via a
  weighted random sampler so the classifier sees a 50/50 mix each epoch.
"""

import argparse
import os
import sys
import time

import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import DataLoader, WeightedRandomSampler, random_split
from sklearn.metrics import accuracy_score, f1_score

# allow import from project root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config import (
    BATCH_SIZE, CASIA_AUTHENTIC, CASIA_TAMPERED, CASIA_MASKS,
    CLASSIFIER_CKPT, DEVICE, EARLY_STOP, EPOCHS_CLS,
    IMG_SIZE, LR_CLS, MICC_AUTHENTIC, MICC_TAMPERED,
    SPLIT_SEED, TEST_SPLIT, VAL_SPLIT, WEIGHT_DECAY,
)
from core.classifier import ForgeryClassifier
from core.datasets import ForgeryDataset


# ── Parse CLI args ────────────────────────────────────────────────────────────
def _parser():
    p = argparse.ArgumentParser(description="Train forgery classifier")
    p.add_argument("--epochs",      type=int,   default=EPOCHS_CLS)
    p.add_argument("--batch-size",  type=int,   default=BATCH_SIZE)
    p.add_argument("--lr",          type=float, default=LR_CLS)
    return p


# ── Build combined dataset ────────────────────────────────────────────────────
def build_dataset() -> ForgeryDataset:
    ds = ForgeryDataset(
        authentic_dir=CASIA_AUTHENTIC,
        tampered_dir=CASIA_TAMPERED,
        mask_dir=None,                # masks not needed for classification
        phase="classification",
        img_size=IMG_SIZE,
    )
    # Append MICC images if the directory exists
    if os.path.isdir(MICC_AUTHENTIC) or os.path.isdir(MICC_TAMPERED):
        micc_ds = ForgeryDataset(
            authentic_dir=MICC_AUTHENTIC,
            tampered_dir=MICC_TAMPERED,
            mask_dir=None,
            phase="classification",
            img_size=IMG_SIZE,
        )
        ds.samples.extend(micc_ds.samples)

    if len(ds) == 0:
        raise RuntimeError(
            "No images found. Run `python scripts/download_data.py` first "
            "and verify CASIA_AUTHENTIC / CASIA_TAMPERED paths in config.py."
        )
    return ds


def _make_sampler(dataset: ForgeryDataset) -> WeightedRandomSampler:
    """
    Build a WeightedRandomSampler that gives each class equal probability,
    compensating for dataset imbalance (CASIA authentic >> tampered).
    """
    labels  = [int(s["label"]) for s in dataset.samples]
    n_auth  = labels.count(0) or 1
    n_tamp  = labels.count(1) or 1
    w_auth  = 1.0 / n_auth
    w_tamp  = 1.0 / n_tamp
    weights = [w_auth if l == 0 else w_tamp for l in labels]
    return WeightedRandomSampler(weights, num_samples=len(weights), replacement=True)


# ── Training loop ─────────────────────────────────────────────────────────────
def train(args):
    print(f"[Classifier] Device: {DEVICE}")
    print(f"[Classifier] Building dataset …")
    full_ds = build_dataset()
    print(f"[Classifier] Total samples: {len(full_ds)}  "
          f"(authentic={sum(1 for s in full_ds.samples if s['label']==0)}, "
          f"tampered={sum(1 for s in full_ds.samples if s['label']==1)})")

    # ── 3-way split: 70 % train / 10 % val / 20 % test ──────────────────────
    n_test  = int(len(full_ds) * TEST_SPLIT)
    n_val   = int(len(full_ds) * VAL_SPLIT)
    n_train = len(full_ds) - n_val - n_test
    train_ds, val_ds, test_ds = random_split(
        full_ds, [n_train, n_val, n_test],
        generator=torch.Generator().manual_seed(SPLIT_SEED),
    )
    print(f"[Classifier] Split → train={len(train_ds)}  "
          f"val={len(val_ds)}  test={len(test_ds)}  "
          f"(test set is held out — NOT used here)")

    # Assert zero index overlap across all three partitions
    tr_idx = set(train_ds.indices)
    va_idx = set(val_ds.indices)
    te_idx = set(test_ds.indices)
    assert len(tr_idx & va_idx) == 0, "train/val overlap!"
    assert len(tr_idx & te_idx) == 0, "train/test overlap!"
    assert len(va_idx & te_idx) == 0, "val/test overlap!"

    # test_ds is deliberately not used here — evaluation happens in evaluate.py
    sampler    = _make_sampler(train_ds.dataset)
    train_samp = WeightedRandomSampler(
        [sampler.weights[i] for i in train_ds.indices],
        num_samples=n_train, replacement=True)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size,
                              sampler=train_samp, num_workers=0, pin_memory=False)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch_size,
                              shuffle=False, num_workers=0)

    model     = ForgeryClassifier(input_size=IMG_SIZE).to(DEVICE)
    criterion = nn.BCELoss()
    optimizer = Adam(model.parameters(), lr=args.lr, weight_decay=WEIGHT_DECAY)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)

    best_val_loss = float("inf")
    patience_ctr  = 0
    history       = []

    print(f"\n[Classifier] Starting training — {args.epochs} epochs\n")

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()

        # ── train ──
        model.train()
        train_loss = 0.0
        for ela, labels in train_loader:
            ela, labels = ela.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            preds = model(ela)
            loss  = criterion(preds, labels)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * ela.size(0)

        train_loss /= len(train_loader.dataset)

        # ── validate ──
        model.eval()
        val_loss = 0.0
        all_labels, all_preds = [], []
        with torch.no_grad():
            for ela, labels in val_loader:
                ela, labels = ela.to(DEVICE), labels.to(DEVICE)
                preds = model(ela)
                val_loss += criterion(preds, labels).item() * ela.size(0)
                all_labels.extend(labels.cpu().numpy().flatten().tolist())
                all_preds.extend((preds.cpu().numpy().flatten() >= 0.5).tolist())

        val_loss /= len(val_loader.dataset)
        acc = accuracy_score(all_labels, all_preds)
        f1  = f1_score(all_labels, all_preds, average="binary", zero_division=0)

        scheduler.step()

        elapsed = time.time() - t0
        print(f"Epoch {epoch:3d}/{args.epochs} | "
              f"Train Loss: {train_loss:.4f} | "
              f"Val Loss: {val_loss:.4f} | "
              f"Val Acc: {acc:.4f} | Val F1: {f1:.4f} | "
              f"Time: {elapsed:.1f}s")

        history.append({
            "epoch": epoch, "train_loss": train_loss,
            "val_loss": val_loss, "val_acc": acc, "val_f1": f1,
        })

        # ── checkpoint ──
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_ctr  = 0
            torch.save(model.state_dict(), CLASSIFIER_CKPT)
            print(f"  ↳ Best model saved → {CLASSIFIER_CKPT}")
        else:
            patience_ctr += 1
            if patience_ctr >= EARLY_STOP:
                print(f"\n[Classifier] Early stopping triggered at epoch {epoch}.")
                break

    print(f"\n[Classifier] Training complete. Best val loss: {best_val_loss:.4f}")
    return history


if __name__ == "__main__":
    args = _parser().parse_args()
    train(args)
