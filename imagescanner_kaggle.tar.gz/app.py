"""
app.py — Flask web application for the Image Forgery Detection System.

Routes
------
GET  /                      Upload page (index)
POST /analyze               Run inference, store result, redirect to /result/<id>
GET  /result/<id>           Full analysis dashboard
GET  /history               Paginated analysis history (SQLite)
GET  /how-it-works          Educational pipeline explainer
POST /api/analyze           REST JSON endpoint
POST /api/reanalyze/<id>    Re-run with different ELA quality / mask threshold
GET  /download/pdf/<id>     ReportLab PDF forensic report
GET  /download/json/<id>    JSON export
GET  /download/mask/<id>/<t> Mask or overlay PNG
"""

import io
import json
import os
import sqlite3
import uuid
from datetime import datetime
from functools import wraps

from flask import (Flask, jsonify, redirect, render_template, request,
                   send_file, session, url_for)
from werkzeug.utils import secure_filename

from config import (ALLOWED_EXTENSIONS, HISTORY_DB, MAX_CONTENT_LENGTH,
                    RESULTS_FOLDER, SECRET_KEY, UPLOAD_FOLDER, SEG_THRESHOLD)
from core.inference import run_inference

# ── App setup ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
app.config["UPLOAD_FOLDER"]      = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER,  exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)


# ── SQLite helpers ────────────────────────────────────────────────────────────
def _get_db():
    conn = sqlite3.connect(HISTORY_DB)
    conn.row_factory = sqlite3.Row
    return conn


def _init_db():
    with _get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS analyses (
                id             TEXT PRIMARY KEY,
                filename       TEXT NOT NULL,
                timestamp      TEXT NOT NULL,
                verdict        TEXT NOT NULL,
                confidence     REAL NOT NULL,
                inference_time REAL NOT NULL,
                result_json    TEXT NOT NULL,
                thumbnail_path TEXT
            )
        """)
        conn.commit()


_init_db()


def _save_analysis(result: dict, filename: str):
    thumbnail = result["paths"]["original"]
    with _get_db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO analyses
               (id, filename, timestamp, verdict, confidence,
                inference_time, result_json, thumbnail_path)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                result["id"],
                filename,
                datetime.utcnow().isoformat(),
                result["verdict"],
                result["confidence_tampered"],
                result["inference_time_s"],
                json.dumps(result),
                thumbnail,
            ),
        )
        conn.commit()


def _load_analysis(analysis_id: str) -> dict | None:
    with _get_db() as conn:
        row = conn.execute(
            "SELECT result_json FROM analyses WHERE id = ?", (analysis_id,)
        ).fetchone()
    return json.loads(row["result_json"]) if row else None


def _list_analyses(page: int = 1, per_page: int = 12,
                   search: str = "", verdict_filter: str = "") -> tuple:
    base_q = "SELECT * FROM analyses WHERE 1=1"
    params: list = []
    if search:
        base_q += " AND filename LIKE ?"
        params.append(f"%{search}%")
    if verdict_filter in ("TAMPERED", "AUTHENTIC"):
        base_q += " AND verdict = ?"
        params.append(verdict_filter)

    with _get_db() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) FROM ({base_q})", params).fetchone()[0]
        rows = conn.execute(
            f"{base_q} ORDER BY timestamp DESC LIMIT ? OFFSET ?",
            params + [per_page, (page - 1) * per_page],
        ).fetchall()

    return [dict(r) for r in rows], total


# ── File validation ───────────────────────────────────────────────────────────
def _allowed(filename: str) -> bool:
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


def _url_for_result_image(result: dict, key: str) -> str | None:
    """Convert an absolute path to a Flask static URL."""
    path = result.get("paths", {}).get(key)
    if not path or not os.path.exists(path):
        return None
    rel = os.path.relpath(path, os.path.join(app.root_path, "static"))
    return url_for("static", filename=rel.replace("\\", "/"))


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    if "image" not in request.files:
        return render_template("index.html", error="No file part in request.")
    file = request.files["image"]
    if file.filename == "":
        return render_template("index.html", error="No file selected.")
    if not _allowed(file.filename):
        return render_template(
            "index.html",
            error=f"Unsupported file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}",
        )

    ela_q = request.form.get("ela_quality", 90, type=int)
    ela_q = max(50, min(99, ela_q))

    filename  = secure_filename(file.filename)
    save_path = os.path.join(UPLOAD_FOLDER, f"{uuid.uuid4()}_{filename}")
    file.save(save_path)

    try:
        result = run_inference(save_path, ela_quality=ela_q)
    except Exception as exc:
        os.remove(save_path)
        return render_template("index.html", error=f"Analysis failed: {exc}")

    _save_analysis(result, filename)
    return redirect(url_for("result", analysis_id=result["id"]))


@app.route("/result/<analysis_id>")
def result(analysis_id: str):
    data = _load_analysis(analysis_id)
    if data is None:
        return render_template("index.html", error="Analysis not found.")

    # Convert absolute paths → static URLs for the template
    image_urls = {
        k: _url_for_result_image(data, k)
        for k in ("original", "ela", "gradcam", "overlay",
                  "vgg_mask", "resnet_mask", "agreement")
    }
    return render_template("result.html", data=data, image_urls=image_urls)


@app.route("/history")
def history():
    page     = request.args.get("page", 1, type=int)
    search   = request.args.get("search", "")
    vfilter  = request.args.get("verdict", "")
    per_page = 12
    rows, total = _list_analyses(page, per_page, search, vfilter)
    # Attach thumbnail URLs
    for row in rows:
        tp = row.get("thumbnail_path")
        if tp and os.path.exists(tp):
            rel = os.path.relpath(tp, os.path.join(app.root_path, "static"))
            row["thumbnail_url"] = url_for("static", filename=rel.replace("\\", "/"))
        else:
            row["thumbnail_url"] = None
    total_pages = max(1, (total + per_page - 1) // per_page)
    return render_template("history.html", rows=rows, page=page,
                           total_pages=total_pages, total=total,
                           search=search, verdict=vfilter)


@app.route("/history/clear", methods=["POST"])
def clear_history():
    with _get_db() as conn:
        conn.execute("DELETE FROM analyses")
        conn.commit()
    return redirect(url_for("history"))


@app.route("/how-it-works")
def how_it_works():
    return render_template("how_it_works.html")


@app.route("/results-file/<path:filepath>")
def results_file(filepath):
    """Serve files from the results/ folder (outside static/)."""
    results_dir = os.path.join(app.root_path, "results")
    return send_file(os.path.join(results_dir, filepath))


@app.route("/eval-results")
def eval_results():
    results_dir = os.path.join(app.root_path, "results")

    def _to_url(rel_file):
        """Return a URL for a file relative to results/."""
        if os.path.exists(os.path.join(results_dir, rel_file)):
            return url_for("results_file", filepath=rel_file.replace("\\", "/"))
        return None

    # Build image groups with metadata
    GROUPS = [
        {
            "id": "tables",
            "title": "Publication Tables",
            "icon": "bi-table",
            "color": "#6366f1",
            "description": (
                "Five publication-grade tables summarising classification "
                "accuracy, segmentation localisation metrics, ablation results, "
                "state-of-the-art comparison, and system efficiency."
            ),
            "items": [
                {
                    "file": "tables/table1_classification.png",
                    "title": "Table 1 — Classification Performance",
                    "desc": "Accuracy, Precision, Recall, F1 and AUC across all three datasets "
                            "(CASIA in-domain, CoMoFoD and Columbia cross-domain). "
                            "Shows how well the CNN classifier generalises beyond its training set.",
                },
                {
                    "file": "tables/table2_localization.png",
                    "title": "Table 2 — Localisation Performance",
                    "desc": "Pixel-level IoU, Dice/F1, Pixel Accuracy, FPR and parameter count "
                            "for both VGG16-UNet and ResNet50-UNet across all datasets. "
                            "ResNet50 consistently outperforms VGG16 on IoU and Dice.",
                },
                {
                    "file": "tables/table3_ablation.png",
                    "title": "Table 3 — Ablation Study",
                    "desc": "Baseline (RGB, Val-Loss checkpoint) vs Improved (RGB+ELA 6-channel, IoU checkpoint) "
                            "training protocol. The improved setup yields +6.9% (VGG16) and +14.6% (ResNet50) IoU gain.",
                },
                {
                    "file": "tables/table4_sota.png",
                    "title": "Table 4 — State-of-the-Art Comparison",
                    "desc": "Places ForensicLens against recent published methods. "
                            "This work is the only system tested on all three datasets simultaneously "
                            "while maintaining competitive segmentation IoU.",
                },
                {
                    "file": "tables/table5_efficiency.png",
                    "title": "Table 5 — System Efficiency",
                    "desc": "Parameter counts (Millions) and per-image inference time (ms) for each component. "
                            "Useful for understanding real-world deployment feasibility on CPU and GPU.",
                },
            ],
        },
        {
            "id": "roc_pr",
            "title": "ROC & Precision-Recall Curves",
            "icon": "bi-graph-up-arrow",
            "color": "#8b5cf6",
            "description": (
                "Receiver Operating Characteristic and Precision-Recall curves "
                "illustrate the classifier's separability across all three evaluation domains."
            ),
            "items": [
                {
                    "file": "roc_curve_casia.png",
                    "title": "ROC Curve — CASIA v2.0 (In-Domain)",
                    "desc": "Single-dataset ROC with AUC score. CASIA is the primary benchmark "
                            "on which the classifier was trained. A high AUC here confirms the "
                            "model has learned strong ELA-based discrimination features.",
                },
                {
                    "file": "roc_curves_combined.png",
                    "title": "Combined ROC Curves — All Datasets",
                    "desc": "Overlaid ROC curves for CASIA, CoMoFoD, and Columbia on a single plot. "
                            "The proximity of all curves reveals strong cross-domain generalisation "
                            "without any fine-tuning.",
                },
                {
                    "file": "pr_curves_combined.png",
                    "title": "Combined Precision-Recall Curves — All Datasets",
                    "desc": "PR curves are more informative than ROC when classes are imbalanced. "
                            "High Average Precision (AP) values confirm the model avoids false positives "
                            "even at high recall thresholds — crucial for forensic use.",
                },
            ],
        },
        {
            "id": "confusion",
            "title": "Confusion Matrices",
            "icon": "bi-grid-3x3-gap-fill",
            "color": "#ec4899",
            "description": (
                "Per-dataset confusion matrices show exact True Positive, False Positive, "
                "True Negative and False Negative counts for the binary classifier."
            ),
            "items": [
                {
                    "file": "confusion_matrix_casia.png",
                    "title": "Confusion Matrix — CASIA v2.0",
                    "desc": "Primary benchmark confusion matrix. Low false-negative count confirms "
                            "the classifier rarely misses actual forgeries (high Recall).",
                },
                {
                    "file": "confusion_matrix_comofod.png",
                    "title": "Confusion Matrix — CoMoFoD",
                    "desc": "Cross-domain result on copy-move forgeries at 512×512. "
                            "Any increase in false positives here reveals the classifier's sensitivity "
                            "to copy-move compression artefacts unseen during training.",
                },
                {
                    "file": "confusion_matrix_columbia.png",
                    "title": "Confusion Matrix — Columbia",
                    "desc": "Cross-domain result on image splicing. Columbia images are typically "
                            "uncompressed TIFFs — the most challenging scenario for an ELA-based system. "
                            "Performance here tests the model's limits.",
                },
            ],
        },
        {
            "id": "backbone",
            "title": "Backbone Comparison Charts",
            "icon": "bi-bar-chart-steps",
            "color": "#f97316",
            "description": (
                "Side-by-side bar charts comparing VGG16-UNet vs ResNet50-UNet "
                "on every segmentation metric per dataset."
            ),
            "items": [
                {
                    "file": "backbone_comparison_casia.png",
                    "title": "Backbone Comparison — CASIA v2.0",
                    "desc": "In-domain segmentation comparison. ResNet50's deeper residual features "
                            "produce higher IoU and Dice, particularly for small tampered regions.",
                },
                {
                    "file": "backbone_comparison_comofod.png",
                    "title": "Backbone Comparison — CoMoFoD",
                    "desc": "Cross-domain copy-move segmentation. Both backbones were evaluated "
                            "without fine-tuning on CoMoFoD, making this a direct test of generalisation.",
                },
                {
                    "file": "backbone_comparison_columbia.png",
                    "title": "Backbone Comparison — Columbia",
                    "desc": "Cross-domain splicing segmentation on uncompressed images. "
                            "The gap between VGG16 and ResNet50 here indicates which encoder "
                            "is more robust to out-of-distribution compression styles.",
                },
            ],
        },
        {
            "id": "qualitative",
            "title": "Qualitative Visual Grids",
            "icon": "bi-images",
            "color": "#22c55e",
            "description": (
                "Five-row visual grids (Input → ELA Map → Ground Truth → VGG16 Prediction "
                "→ ResNet50 Prediction) for representative success cases, cross-domain "
                "challenges, and failure cases."
            ),
            "items": [
                {
                    "file": "qualitative/grid_success_casia.png",
                    "title": "Grid A — Success Cases (CASIA v2.0, In-Domain)",
                    "desc": "Best-case predictions on tampered CASIA images. Both models accurately "
                            "delineate forged regions. The ELA column shows bright artefacts that "
                            "align tightly with the ground-truth mask.",
                },
                {
                    "file": "qualitative/grid_crossdomain_comofod.png",
                    "title": "Grid B — Cross-Domain Challenge (CoMoFoD)",
                    "desc": "Models trained only on CASIA applied directly to copy-move CoMoFoD images. "
                            "Evaluates whether ELA artefacts from copy-move forgeries look similar "
                            "enough to splicing artefacts for the models to generalise.",
                },
                {
                    "file": "qualitative/grid_failure_cases.png",
                    "title": "Grid C — Failure Case Analysis",
                    "desc": "Worst-performing predictions selected by lowest average IoU. "
                            "Common failure patterns include small forged regions, heavily blurred "
                            "boundaries, and images with uniformly low ELA response (e.g., PNGs).",
                },
            ],
        },
    ]

    # Resolve every item's path → static URL
    for grp in GROUPS:
        for item in grp["items"]:
            item["url"] = _to_url(item["file"])
            item["exists"] = bool(item["url"])

    # Load summary JSON for key numbers
    summary = {}
    summary_path = os.path.join(results_dir, "eval_summary.json")
    if os.path.exists(summary_path):
        with open(summary_path) as f:
            summary = json.load(f)

    return render_template("eval_results.html", groups=GROUPS, summary=summary)


# ── REST API ──────────────────────────────────────────────────────────────────

@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    if "image" not in request.files:
        return jsonify({"error": "No image file provided."}), 400
    file = request.files["image"]
    if not _allowed(file.filename):
        return jsonify({"error": "Unsupported file type."}), 400

    ela_q     = request.form.get("ela_quality", 90, type=int)
    filename  = secure_filename(file.filename)
    save_path = os.path.join(UPLOAD_FOLDER, f"{uuid.uuid4()}_{filename}")
    file.save(save_path)

    try:
        result = run_inference(save_path, ela_quality=ela_q)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

    _save_analysis(result, filename)
    # Return lightweight JSON (omit per-pixel data)
    return jsonify({
        "id":              result["id"],
        "verdict":         result["verdict"],
        "confidence":      result["confidence_tampered"],
        "inference_time":  result["inference_time_s"],
        "models_trained":  result["models_trained"],
        "image_info":      result["image_info"],
        "segmentation":    result["segmentation"],
        "exif_warnings":   result["exif_warnings"],
        "explanation":     result["explanation"],
    })


@app.route("/api/reanalyze/<analysis_id>", methods=["POST"])
def api_reanalyze(analysis_id: str):
    old = _load_analysis(analysis_id)
    if old is None:
        return jsonify({"error": "Analysis not found."}), 404

    ela_q     = request.json.get("ela_quality", 90)
    threshold = request.json.get("seg_threshold", SEG_THRESHOLD)
    original  = old["paths"]["original"]
    if not os.path.exists(original):
        return jsonify({"error": "Original image no longer on disk."}), 404

    try:
        result = run_inference(original, ela_quality=ela_q,
                               seg_threshold=threshold)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

    _save_analysis(result, old["image_info"]["filename"])
    return jsonify({"redirect": url_for("result", analysis_id=result["id"])})


# ── Download endpoints ────────────────────────────────────────────────────────

@app.route("/download/json/<analysis_id>")
def download_json(analysis_id: str):
    data = _load_analysis(analysis_id)
    if data is None:
        return "Not found", 404
    buf = io.BytesIO(json.dumps(data, indent=2).encode())
    buf.seek(0)
    return send_file(buf, mimetype="application/json",
                     download_name=f"forensic_{analysis_id[:8]}.json",
                     as_attachment=True)


@app.route("/download/mask/<analysis_id>/<mask_type>")
def download_mask(analysis_id: str, mask_type: str):
    data = _load_analysis(analysis_id)
    if data is None:
        return "Not found", 404
    path = data.get("paths", {}).get(mask_type)
    if not path or not os.path.exists(path):
        return "File not found", 404
    return send_file(path, mimetype="image/jpeg",
                     download_name=f"{mask_type}_{analysis_id[:8]}.jpg",
                     as_attachment=True)


@app.route("/download/pdf/<analysis_id>")
def download_pdf(analysis_id: str):
    data = _load_analysis(analysis_id)
    if data is None:
        return "Not found", 404
    try:
        pdf_bytes = _generate_pdf(data)
    except Exception as exc:
        return f"PDF generation error: {exc}", 500
    buf = io.BytesIO(pdf_bytes)
    buf.seek(0)
    return send_file(buf, mimetype="application/pdf",
                     download_name=f"forensic_report_{analysis_id[:8]}.pdf",
                     as_attachment=True)


# ── PDF generation (ReportLab) ────────────────────────────────────────────────

def _generate_pdf(data: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import (Image as RLImage, Paragraph,
                                    SimpleDocTemplate, Spacer, Table,
                                    TableStyle)

    buf      = io.BytesIO()
    doc      = SimpleDocTemplate(buf, pagesize=A4,
                                 leftMargin=2*cm, rightMargin=2*cm,
                                 topMargin=2*cm, bottomMargin=2*cm)
    styles   = getSampleStyleSheet()
    story    = []

    # ── Title ──
    title_style = ParagraphStyle(
        "Title2", parent=styles["Title"],
        fontSize=20, textColor=colors.HexColor("#1a1a2e"), spaceAfter=6)
    story.append(Paragraph("🔍 Forensic Image Analysis Report", title_style))
    story.append(Spacer(1, 0.2*cm))

    sub_style = ParagraphStyle(
        "Sub", parent=styles["Normal"],
        fontSize=9, textColor=colors.grey)
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    story.append(Paragraph(f"Generated: {ts}  |  Analysis ID: {data['id'][:8]}",
                            sub_style))
    story.append(Spacer(1, 0.5*cm))

    # ── Verdict banner ──
    verdict   = data["verdict"]
    conf_pct  = round(data["confidence_tampered"] * 100, 1)
    v_color   = colors.HexColor("#dc2626") if verdict == "TAMPERED" else colors.HexColor("#16a34a")
    v_data    = [[
        Paragraph(f"<b>VERDICT: {verdict}</b>", ParagraphStyle(
            "V", parent=styles["Normal"],
            fontSize=16, textColor=colors.white)),
        Paragraph(f"Confidence: {conf_pct}%<br/>Inference: {data['inference_time_s']}s",
                  ParagraphStyle("Vc", parent=styles["Normal"],
                                 fontSize=10, textColor=colors.white)),
    ]]
    v_table = Table(v_data, colWidths=["70%", "30%"])
    v_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), v_color),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [v_color]),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
    ]))
    story.append(v_table)
    story.append(Spacer(1, 0.5*cm))

    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=13,
                         textColor=colors.HexColor("#1a1a2e"), spaceBefore=10)
    normal = styles["Normal"]

    # ── Image info ──
    story.append(Paragraph("Image Information", h2))
    info = data["image_info"]
    info_rows = [
        ["Filename", info.get("filename", "—")],
        ["Dimensions", f"{info.get('width')} × {info.get('height')} px"],
        ["Mode", info.get("mode", "RGB")],
        ["ELA Quality", str(data["ela"]["quality"])],
        ["Models trained", "Yes" if data.get("models_trained") else "No (demo mode)"],
    ]
    _add_table(story, info_rows, styles)

    # ── Result images ──
    story.append(Paragraph("Visual Evidence", h2))
    img_pairs = [
        ("Original", "original"), ("ELA Map", "ela"),
        ("Grad-CAM", "gradcam"), ("Overlay / Mask", "overlay"),
    ]
    row_imgs = []
    for label, key in img_pairs:
        path = data.get("paths", {}).get(key)
        if path and os.path.exists(path):
            try:
                rl_img = RLImage(path, width=7*cm, height=7*cm,
                                 kind="proportional")
                row_imgs.append([Paragraph(label, sub_style), rl_img])
            except Exception:
                pass
    for i in range(0, len(row_imgs), 2):
        pair   = row_imgs[i:i+2]
        labels = [p[0] for p in pair] + [Paragraph("", sub_style)] * (2 - len(pair))
        imgs   = [p[1] for p in pair] + [Spacer(1, 1)] * (2 - len(pair))
        t = Table([labels, imgs], colWidths=["50%", "50%"])
        t.setStyle(TableStyle([
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(t)

    story.append(Spacer(1, 0.3*cm))

    # ── Segmentation stats ──
    if verdict == "TAMPERED":
        seg = data.get("segmentation", {})
        r50 = seg.get("resnet50", {})
        v16 = seg.get("vgg16", {})
        n_r50 = len(r50.get("regions", []))
        n_v16 = len(v16.get("regions", []))
        
        story.append(Paragraph("Segmentation Analysis", h2))
        
        if n_r50 == 0 and n_v16 == 0:
            story.append(Paragraph("No localised tampered regions were detected by the segmentation models. This suggests the tampering was likely global or structural.", normal))
        else:
            seg_rows = [
                ["Backbone", "Severity %", "Regions detected"],
                ["ResNet50-UNet", f"{r50.get('severity_pct', 0):.2f}%", str(n_r50)],
                ["VGG16-UNet",   f"{v16.get('severity_pct', 0):.2f}%", str(n_v16)],
                ["Backbone Agreement", f"{seg.get('backbone_agree_pct', 0):.1f}%",
                 f"IoU = {seg.get('backbone_iou', 0):.4f}"],
            ]
            _add_table(story, seg_rows, styles, header=True)

    # ── EXIF ──
    story.append(Paragraph("EXIF Metadata", h2))
    exif = data.get("exif", {})
    if exif:
        for k, v in exif.items():
            story.append(Paragraph(f"<b>{k}:</b> {v}", normal))
    else:
        story.append(Paragraph("No EXIF metadata found.", normal))
    for w in data.get("exif_warnings", []):
        story.append(Paragraph(f"⚠ {w}", ParagraphStyle(
            "Warn", parent=normal, textColor=colors.red)))

    # ── Explanation ──
    story.append(Paragraph("Auto-generated Explanation", h2))
    story.append(Paragraph(data.get("explanation", ""), normal))

    doc.build(story)
    return buf.getvalue()


def _add_table(story, rows, styles, header=False):
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.platypus import Table, TableStyle

    tbl = Table([[str(c) for c in r] for r in rows],
                colWidths=None, hAlign="LEFT")
    ts  = [
        ("GRID",        (0, 0), (-1, -1), 0.4, colors.HexColor("#e5e7eb")),
        ("TOPPADDING",  (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("FONTSIZE",    (0, 0), (-1, -1), 9),
    ]
    if header:
        ts += [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
            ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
            ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ]
    tbl.setStyle(TableStyle(ts))
    story.append(tbl)
    from reportlab.platypus import Spacer
    story.append(Spacer(1, 0.3*cm))


# ── Run ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
