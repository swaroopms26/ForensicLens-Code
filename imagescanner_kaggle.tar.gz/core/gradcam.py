"""
core/gradcam.py — Gradient-weighted Class Activation Mapping (Grad-CAM).

Wraps ForgeryClassifier and targets the last Conv2d layer (128 filters) that
is already hooked inside the model's forward pass.  The output is a spatial
saliency map highlighting regions that drove the classification decision.

Reference: Selvaraju et al., "Grad-CAM: Visual Explanations from Deep
           Networks via Gradient-based Localization", ICCV 2017.
"""
import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image


class GradCAM:
    """
    Grad-CAM generator for ForgeryClassifier.

    Usage::

        model = ForgeryClassifier()
        gcam  = GradCAM(model, device="cpu")
        grey, overlay = gcam.generate(ela_tensor, original_pil)
    """

    def __init__(self, model, device: str = "cpu"):
        self.model  = model.to(device)
        self.device = device

    # ------------------------------------------------------------------ #
    def generate(
        self,
        ela_tensor,         # (1, 3, H, W) float32 — NOT yet on device
        original_pil: Image.Image,
        img_size: tuple = (256, 256),
    ):
        """
        Compute Grad-CAM heatmap.

        Args:
            ela_tensor   : shape (1, 3, H, W), values in [0, 1]
            original_pil : PIL RGB image to blend overlay onto
            img_size     : (H, W) for output images

        Returns:
            heatmap_grey : np.uint8 array (H, W), 0-255 greyscale cam
            overlay_bgr  : np.uint8 array (H, W, 3), BGR heatmap blended
                           onto the original image
        """
        self.model.eval()

        # Ensure gradients flow through the ELA input
        x = ela_tensor.clone().to(self.device).requires_grad_(True)

        output = self.model(x)          # scalar in [0,1]
        self.model.zero_grad()
        output.backward(torch.ones_like(output))

        gradients  = self.model.get_activations_gradient()   # (1, C, h, w)
        activations = self.model.activations                  # (1, C, h, w)

        # Graceful fallback if hooks didn't fire (e.g. untrained model)
        if gradients is None or activations is None:
            blank = np.zeros(img_size, dtype=np.uint8)
            orig_np = np.array(original_pil.resize(img_size[::-1]).convert("RGB"))
            return blank, cv2.cvtColor(orig_np, cv2.COLOR_RGB2BGR)

        # Global-average-pool the gradients → per-channel weights
        weights = gradients.mean(dim=[2, 3], keepdim=True)     # (1, C, 1, 1)
        cam = (weights * activations).sum(dim=1, keepdim=True)  # (1, 1, h, w)
        cam = F.relu(cam)                                        # drop negatives

        cam_np = cam.squeeze().detach().cpu().numpy()           # (h, w)

        # Normalise to [0, 255]
        cam_np = cam_np - cam_np.min()
        if cam_np.max() > 0:
            cam_np = cam_np / cam_np.max()
        cam_np = (cam_np * 255).astype(np.uint8)

        # Upsample to full image size  (cv2 uses W, H order)
        cam_resized = cv2.resize(cam_np, (img_size[1], img_size[0]),
                                 interpolation=cv2.INTER_LINEAR)

        # Colourize
        heatmap_color = cv2.applyColorMap(cam_resized, cv2.COLORMAP_JET)

        # Blend onto original image
        orig_resized = original_pil.resize((img_size[1], img_size[0])).convert("RGB")
        orig_bgr     = cv2.cvtColor(np.array(orig_resized), cv2.COLOR_RGB2BGR)
        overlay_bgr  = cv2.addWeighted(orig_bgr, 0.60, heatmap_color, 0.40, 0)

        return cam_resized, overlay_bgr
