import torch
import torch.nn as nn
import torch.nn.functional as F

class ForgeryClassifier(nn.Module):
    """
    CNN Classifier to determine if an image is Authentic or Tampered
    based on its ELA map. Contains hooks for extracting Grad-CAM heatmaps.
    """
    def __init__(self, input_size=(256, 256)):
        super(ForgeryClassifier, self).__init__()
        self.input_size = input_size
        
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2), # 128x128
            
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2), # 64x64
            
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
        )
        
        self.final_pool = nn.MaxPool2d(2, 2) # 32x32
        
        flatten_dim = 128 * (input_size[0] // 8) * (input_size[1] // 8)
        
        self.classifier = nn.Sequential(
            nn.Linear(flatten_dim, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 1) # Authenticity score (0.0 to 1.0)
        )
        
        # State variables for Grad-CAM
        self.gradients = None
        self.activations = None

    def activations_hook(self, grad):
        self.gradients = grad

    def forward(self, x):
        # Pass through the first part of features directly
        for i in range(len(self.features) - 2):
            x = self.features[i](x)
            
        # Target layer for Grad-CAM (the conv 128)
        x = self.features[-2](x) # Conv2d
        
        if x.requires_grad:
            x.register_hook(self.activations_hook)
        self.activations = x
        
        x = self.features[-1](x) # ReLU
        x = self.final_pool(x)
        
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return torch.sigmoid(x)
        
    def get_activations_gradient(self):
        return self.gradients
    
    def get_activations(self, x):
        return self.activations
