import cv2
import numpy as np
from PIL import Image, ImageChops, ImageEnhance, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

def compute_ela(image_path, quality=90):
    """
    Computes the Error Level Analysis (ELA) of an image.
    ELA highlights regions that have been edited by re-saving the image at a known quality level
    and finding the absolute difference between the original and re-saved image.
    
    Args:
        image_path (str or PIL Image): Path to the image or the Image object itself.
        quality (int): The JPEG quality level to re-save at.
        
    Returns:
        PIL.Image: The enhanced ELA representation.
    """
    if isinstance(image_path, str):
        original = Image.open(image_path).convert('RGB')
    else:
        original = image_path.convert('RGB')
        
    # Re-save the original image at the specified quality level
    # We use a temporary file or memory buffer. Using memory buffer for speed.
    import io
    temp_buffer = io.BytesIO()
    original.save(temp_buffer, 'JPEG', quality=quality)
    temp_buffer.seek(0)
    
    resaved = Image.open(temp_buffer).convert('RGB')
    
    # Calculate difference between original and resaved image
    ela_image = ImageChops.difference(original, resaved)
    
    # Get the extrema (min/max diff values) to auto-adjust brightness
    extrema = ela_image.getextrema()
    max_diff = max([ex[1] for ex in extrema])
    
    if max_diff == 0:
        max_diff = 1 # Avoid division by zero if identical
        
    scale = 255.0 / max_diff
    
    # Enhance the ELA image by scaling up the differences
    ela_image = ImageEnhance.Brightness(ela_image).enhance(scale)
    
    return ela_image

def ela_transform(image_path, target_size=(256, 256), quality=90):
    """
    Creates an ELA map, converts to numpy array, resizes, and normalizes it.
    This serves as the main preprocessing pipeline for the deep learning models.
    """
    ela_img = compute_ela(image_path, quality)
    ela_img = ela_img.resize(target_size, Image.BILINEAR)
    
    # Convert to numpy array and normalize [0, 1]
    ela_array = np.array(ela_img, dtype=np.float32) / 255.0
    
    return ela_array
