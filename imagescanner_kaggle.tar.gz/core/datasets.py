import os
from glob import glob
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from core.ela import ela_transform

class ForgeryDataset(Dataset):
    """
    Generic dataset for Image Forgery that applies ELA. 
    It supports returning just (ELA, Label) for Classification,
    or (ELA, Mask) for Segmentation.
    """
    def __init__(self, authentic_dir=None, tampered_dir=None, mask_dir=None, phase='classification', img_size=(256, 256)):
        self.phase = phase
        self.img_size = img_size
        self.samples = []
        self.transform_tensor = transforms.Compose([
            transforms.ToTensor()
        ])
        
        # Collect authentic images
        if authentic_dir and os.path.exists(authentic_dir):
            for f in glob(os.path.join(authentic_dir, '*.*')):
                if f.lower().endswith(('png', 'jpg', 'jpeg', 'tif', 'tiff')):
                    self.samples.append({
                        'img_path': f,
                        'label': 0.0, # Authentic
                        'mask_path': None
                    })
                    
        # Collect tampered images
        masks_found = 0
        masks_missed = 0
        if tampered_dir and os.path.exists(tampered_dir):
            for f in glob(os.path.join(tampered_dir, '*.*')):
                if f.lower().endswith(('png', 'jpg', 'jpeg', 'tif', 'tiff')):
                    basename = os.path.basename(f)
                    name_no_ext = os.path.splitext(basename)[0]
                    
                    # Try to find corresponding mask with multiple naming conventions
                    m_path = None
                    if mask_dir and os.path.exists(mask_dir):
                        possible_masks = [
                            # Exact same filename
                            os.path.join(mask_dir, basename),
                            # Same name but .png extension
                            os.path.join(mask_dir, name_no_ext + '.png'),
                            # CASIA v2 convention: append _gt before extension
                            os.path.join(mask_dir, name_no_ext + '_gt.png'),
                            os.path.join(mask_dir, name_no_ext + '_gt.bmp'),
                            os.path.join(mask_dir, name_no_ext + '_gt.tif'),
                            os.path.join(mask_dir, name_no_ext + '_gt.jpg'),
                            # Some datasets use _mask suffix
                            os.path.join(mask_dir, name_no_ext + '_mask.png'),
                            # Same name but .bmp extension
                            os.path.join(mask_dir, name_no_ext + '.bmp'),
                            # Same name but .tif extension
                            os.path.join(mask_dir, name_no_ext + '.tif'),
                            # CoMoFoD convention: NNN_F*.png -> NNN_B.png
                            os.path.join(mask_dir, name_no_ext.split('_')[0] + '_B.png'),
                            os.path.join(mask_dir, name_no_ext.split('_')[0] + '_B.bmp'),
                        ]
                        for pm in possible_masks:
                            if os.path.exists(pm):
                                m_path = pm
                                break
                        
                        # Fallback: search for any file in mask_dir whose name starts with name_no_ext
                        if m_path is None:
                            for mf in os.listdir(mask_dir):
                                mf_stem = os.path.splitext(mf)[0]
                                if mf_stem.startswith(name_no_ext) or name_no_ext.startswith(mf_stem):
                                    candidate = os.path.join(mask_dir, mf)
                                    if os.path.isfile(candidate):
                                        m_path = candidate
                                        break
                    
                    if m_path is not None:
                        masks_found += 1
                    else:
                        masks_missed += 1

                    self.samples.append({
                        'img_path': f,
                        'label': 1.0, # Tampered
                        'mask_path': m_path
                    })
        
        # Print diagnostic info
        print(f"[ForgeryDataset] Phase: {phase}")
        print(f"[ForgeryDataset] Authentic: {sum(1 for s in self.samples if s['label'] == 0.0)}")
        print(f"[ForgeryDataset] Tampered: {sum(1 for s in self.samples if s['label'] == 1.0)}")
        print(f"[ForgeryDataset] Masks found: {masks_found}, Masks missing: {masks_missed}")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        # ELA Preprocessing
        ela_array = ela_transform(sample['img_path'], target_size=self.img_size)
        ela_tensor = torch.from_numpy(ela_array).permute(2, 0, 1) # CxHxW
        
        if self.phase == 'classification':
            label_tensor = torch.tensor([sample['label']], dtype=torch.float32)
            return ela_tensor, label_tensor
            
        elif self.phase == 'segmentation':
            if sample['mask_path'] is not None:
                mask_img = Image.open(sample['mask_path']).convert('L')
                mask_img = mask_img.resize(self.img_size, Image.NEAREST)
                mask_tensor = self.transform_tensor(mask_img)
                # Ensure mask is binary 0/1 (some masks are 0-255)
                if mask_tensor.max() > 1.0:
                    mask_tensor = (mask_tensor > 0.5).float()
            else:
                # No mask available — return all-zero mask
                mask_tensor = torch.zeros((1, self.img_size[0], self.img_size[1]), dtype=torch.float32)
                
            return ela_tensor, mask_tensor
