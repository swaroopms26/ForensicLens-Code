"""
core/inference.py — Unified six-stage forgery detection pipeline.

Stage order (matches the research paper's methodology):
  1  ELA preprocessing
  2  Classification (CNN on ELA map)
  3  Grad-CAM saliency
  4  Feature encoding (ResNet50 / VGG16 backbone)
  5  Mask decoding (U-Net decoder → binary mask)
  6  Post-processing: connected-component analysis, EXIF forensics

Models are loaded lazily on the first call and then cached as module-level
singletons — the Flask app therefore pays the load overhead only once.

If checkpoint files are absent the pipeline still runs with randomly-initialised
weights; the caller receives a `models_trained` flag set to False so the UI
can display a warning banner.

No Flask imports — this module is framework-agnostic.
"""
from __future__ import annotations

import io
import os
import time
import uuid

import cv2
import numpy as np
import torch
from PIL import Image

# EXIF reading — piexif is listed in requirements.txt
try:
    import piexif
    _PIEXIF_OK = True
except ImportError:
    _PIEXIF_OK = False

from config import (
    CLASSIFIER_CKPT, CLS_THRESHOLD, DEVICE, ELA_QUALITY, IMG_SIZE,
    RESNET50_SEG_CKPT, RESULTS_FOLDER, SEG_THRESHOLD, VGG16_SEG_CKPT,
)
from core.classifier import ForgeryClassifier
from core.ela import compute_ela, ela_transform
from core.gradcam import GradCAM
from core.segmentation import ResNet50_UNet, VGG16_UNet

# ── Model singletons ──────────────────────────────────────────────────────────
_classifier: ForgeryClassifier | None = None
_vgg_seg:    VGG16_UNet        | None = None
_resnet_seg: ResNet50_UNet     | None = None
_gradcam:    GradCAM           | None = None
_models_trained = False          # flipped True if at least one ckpt loaded


def _load_models() -> bool:
    """Lazy-load all three models.  Returns True if checkpoints were found."""
    global _classifier, _vgg_seg, _resnet_seg, _gradcam, _models_trained

    # If all models are already loaded, just return the existing flag.
    if _classifier is not None and _vgg_seg is not None and _resnet_seg is not None:
        return _models_trained

    ckpt_found = False

    if _classifier is None:
        _classifier = ForgeryClassifier(input_size=IMG_SIZE).to(DEVICE)
        if os.path.exists(CLASSIFIER_CKPT):
            # Strip module prefix in case of DataParallel checkpoints
            state = torch.load(CLASSIFIER_CKPT, map_location=DEVICE)
            if any(k.startswith("module.") for k in state):
                state = {k.replace("module.", ""): v for k, v in state.items()}
            _classifier.load_state_dict(state)
            ckpt_found = True
        _classifier.eval()
        _gradcam = GradCAM(_classifier, device=DEVICE)

    if _vgg_seg is None:
        _vgg_seg = VGG16_UNet().to(DEVICE)
        if os.path.exists(VGG16_SEG_CKPT):
            state = torch.load(VGG16_SEG_CKPT, map_location=DEVICE)
            if any(k.startswith("module.") for k in state):
                state = {k.replace("module.", ""): v for k, v in state.items()}
            _vgg_seg.load_state_dict(state)
            ckpt_found = True
        _vgg_seg.eval()

    if _resnet_seg is None:
        _resnet_seg = ResNet50_UNet().to(DEVICE)
        if os.path.exists(RESNET50_SEG_CKPT):
            state = torch.load(RESNET50_SEG_CKPT, map_location=DEVICE)
            if any(k.startswith("module.") for k in state):
                state = {k.replace("module.", ""): v for k, v in state.items()}
            _resnet_seg.load_state_dict(state)
            ckpt_found = True
        _resnet_seg.eval()

    _models_trained = ckpt_found
    return _models_trained



# ── Helper functions ──────────────────────────────────────────────────────────

def _read_exif(image_path: str) -> tuple[dict, list[str]]:
    """Read EXIF tags; return (metadata_dict, warnings_list)."""
    meta: dict = {}
    warnings: list[str] = []

    if not _PIEXIF_OK:
        warnings.append("piexif not installed — EXIF extraction skipped.")
        return meta, warnings

    try:
        exif_dict = piexif.load(image_path)
        tag_map = {
            "Make":       piexif.ImageIFD.Make,
            "Model":      piexif.ImageIFD.Model,
            "Software":   piexif.ImageIFD.Software,
            "DateTime":   piexif.ImageIFD.DateTime,
            "Artist":     piexif.ImageIFD.Artist,
            "Copyright":  piexif.ImageIFD.Copyright,
        }
        for label, tag in tag_map.items():
            raw = exif_dict.get("0th", {}).get(tag)
            if raw:
                meta[label] = (
                    raw.decode("utf-8", errors="ignore")
                    if isinstance(raw, bytes)
                    else str(raw)
                )
    except Exception:
        pass   # non-JPEG formats return nothing — not an error

    # Suspicious-software heuristic
    _editing_sw = [
        "photoshop", "gimp", "lightroom", "affinity photo",
        "snapseed", "pixelmator", "capture one", "darktable",
        "photo editor", "paint.net", "canva",
    ]
    sw = meta.get("Software", "").lower()
    if any(s in sw for s in _editing_sw):
        warnings.append(
            f"Image processed with known editing software: \"{meta['Software']}\""
        )

    if not meta:
        warnings.append(
            "No EXIF metadata found — image may have been stripped or re-encoded."
        )

    return meta, warnings


def _analyse_mask(mask_uint8: np.ndarray, threshold: float) -> tuple[list, float]:
    """
    Connected-component analysis on a uint8 mask.

    Returns:
        regions      : list of dicts (id, bbox, area_px, area_pct)
        severity_pct : % of image pixels classified as tampered
    """
    h, w = mask_uint8.shape
    binary = (mask_uint8 > int(threshold * 255)).astype(np.uint8)
    num_labels, _, stats, _ = cv2.connectedComponentsWithStats(
        binary, connectivity=8)

    regions = []
    for i in range(1, num_labels):           # skip background label 0
        area = int(stats[i, cv2.CC_STAT_AREA])
        if area < 50:                         # filter tiny specks (noise)
            continue
        x = int(stats[i, cv2.CC_STAT_LEFT])
        y = int(stats[i, cv2.CC_STAT_TOP])
        rw = int(stats[i, cv2.CC_STAT_WIDTH])
        rh = int(stats[i, cv2.CC_STAT_HEIGHT])
        regions.append({
            "id":       i,
            "bbox":     [x, y, rw, rh],
            "area_px":  area,
            "area_pct": round(100.0 * area / (h * w), 2),
        })

    tampered_px = int(binary.sum())
    severity_pct = round(100.0 * tampered_px / (h * w), 2)
    return regions, severity_pct


def _ela_histogram(ela_np: np.ndarray) -> tuple[list, list]:
    """
    ELA intensity histogram (32 bins, greyscale luminance).
    Returns (count_list, bin_left_edges_list).
    """
    lum = (0.2989 * ela_np[:, :, 0]
           + 0.5870 * ela_np[:, :, 1]
           + 0.1140 * ela_np[:, :, 2])
    hist, edges = np.histogram(lum, bins=32, range=(0.0, 1.0))
    return hist.tolist(), [round(float(e), 4) for e in edges[:-1]]


def _save_img(arr_bgr: np.ndarray, path: str) -> None:
    cv2.imwrite(path, arr_bgr)


# ── Public API ────────────────────────────────────────────────────────────────

def run_inference(
    image_path: str,
    ela_quality: int = ELA_QUALITY,
    seg_threshold: float = SEG_THRESHOLD,
) -> dict:
    """
    Run the full forgery detection pipeline on *image_path*.

    Parameters
    ----------
    image_path    : absolute path to the image file on disk
    ela_quality   : JPEG quality for ELA re-compression (50–99)
    seg_threshold : pixel classification threshold for the mask (0–1)

    Returns
    -------
    dict with keys: id, verdict, confidence_tampered, inference_time_s,
                    image_info, ela, classification, segmentation,
                    gradcam, paths, exif, exif_warnings, models_trained
    """
    models_trained = _load_models()
    os.makedirs(RESULTS_FOLDER, exist_ok=True)

    result_id  = str(uuid.uuid4())
    result_dir = os.path.join(RESULTS_FOLDER, result_id)
    os.makedirs(result_dir, exist_ok=True)

    t0 = time.time()

    # ── Stage 1 · ELA preprocessing ──────────────────────────────────────────
    original_pil = Image.open(image_path).convert("RGB")
    orig_w, orig_h = original_pil.size
    orig_resized   = original_pil.resize((IMG_SIZE[1], IMG_SIZE[0]))   # W×H

    ela_pil  = compute_ela(image_path, quality=ela_quality)
    ela_pil_r = ela_pil.resize((IMG_SIZE[1], IMG_SIZE[0]))
    ela_np   = ela_transform(image_path, target_size=IMG_SIZE,
                             quality=ela_quality)                       # (H,W,3) float32

    orig_save = os.path.join(result_dir, "original.jpg")
    ela_save  = os.path.join(result_dir, "ela.jpg")
    orig_resized.save(orig_save, quality=92)
    ela_pil_r.save(ela_save, quality=92)

    ela_hist_vals, ela_hist_bins = _ela_histogram(ela_np)

    ela_tensor = (
        torch.from_numpy(ela_np).permute(2, 0, 1).unsqueeze(0).to(DEVICE)
    )  # (1, 3, H, W)

    # ── Stage 2 · Classification ──────────────────────────────────────────────
    with torch.no_grad():
        cls_score = float(_classifier(ela_tensor).item())

    is_tampered   = cls_score >= CLS_THRESHOLD
    verdict       = "TAMPERED" if is_tampered else "AUTHENTIC"
    conf_tampered = round(cls_score, 4)
    conf_authentic = round(1.0 - cls_score, 4)

    # ── Stage 3 · Grad-CAM ────────────────────────────────────────────────────
    ela_for_grad = torch.from_numpy(ela_np).permute(2, 0, 1).unsqueeze(0)
    gradcam_grey, gradcam_overlay = _gradcam.generate(
        ela_for_grad, orig_resized, img_size=IMG_SIZE)
    gradcam_save   = os.path.join(result_dir, "gradcam.jpg")
    gradcam_g_save = os.path.join(result_dir, "gradcam_grey.jpg")
    _save_img(gradcam_overlay, gradcam_save)
    _save_img(gradcam_grey,    gradcam_g_save)

    # ── Stages 4 & 5 · Segmentation (only for tampered images) ───────────────
    vgg_mask_save = resnet_mask_save = overlay_save = agree_save = None
    vgg_regions, vgg_sev = [], 0.0
    resnet_regions, resnet_sev = [], 0.0
    backbone_iou = None
    backbone_agree_pct = None

    if is_tampered:
        with torch.no_grad():
            vgg_out    = _vgg_seg(ela_tensor)     # (1, 1, H, W) float
            resnet_out = _resnet_seg(ela_tensor)  # (1, 1, H, W) float

        def _to_uint8(t):
            return (t.squeeze().cpu().numpy() * 255).astype(np.uint8)

        vgg_mask_np    = _to_uint8(vgg_out)
        resnet_mask_np = _to_uint8(resnet_out)

        vgg_mask_save    = os.path.join(result_dir, "vgg_mask.jpg")
        resnet_mask_save = os.path.join(result_dir, "resnet_mask.jpg")
        _save_img(vgg_mask_np,    vgg_mask_save)
        _save_img(resnet_mask_np, resnet_mask_save)

        # ── Stage 6 · Localisation overlay ───────────────────────────────────
        resnet_regions, resnet_sev = _analyse_mask(resnet_mask_np, seg_threshold)
        vgg_regions,    vgg_sev    = _analyse_mask(vgg_mask_np,    seg_threshold)

        mask_color  = cv2.applyColorMap(resnet_mask_np, cv2.COLORMAP_HOT)
        orig_bgr    = cv2.cvtColor(np.array(orig_resized), cv2.COLOR_RGB2BGR)
        overlay_np  = cv2.addWeighted(orig_bgr, 0.65, mask_color, 0.35, 0)

        for r in resnet_regions:
            x, y, rw, rh = r["bbox"]
            cv2.rectangle(overlay_np, (x, y), (x + rw, y + rh),
                          (0, 255, 0), 2)
            cv2.putText(overlay_np, f"R{r['id']}", (x + 2, y + 14),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)

        overlay_save = os.path.join(result_dir, "overlay.jpg")
        _save_img(overlay_np, overlay_save)

        # Agreement map  (green=both agree, yellow=only one)
        thr_px   = int(seg_threshold * 255)
        vgg_bin  = (vgg_mask_np    > thr_px).astype(np.uint8)
        res_bin  = (resnet_mask_np > thr_px).astype(np.uint8)
        inter    = (vgg_bin & res_bin).sum()
        union    = (vgg_bin | res_bin).sum()
        backbone_iou        = round(float(inter) / float(union + 1e-6), 4)
        backbone_agree_pct  = round(100.0 * backbone_iou, 2)

        agree_map = np.zeros((*IMG_SIZE, 3), dtype=np.uint8)
        agree_map[(vgg_bin & res_bin) == 1] = [0, 200, 0]    # both  → green
        agree_map[(vgg_bin ^ res_bin) == 1] = [0, 165, 255]  # diff  → orange
        agree_save = os.path.join(result_dir, "agreement.jpg")
        _save_img(cv2.cvtColor(agree_map, cv2.COLOR_RGB2BGR), agree_save)

    # ── EXIF forensics ────────────────────────────────────────────────────────
    exif_meta, exif_warnings = _read_exif(image_path)

    # ── Auto-generated explanation ────────────────────────────────────────────
    def _explain() -> str:
        if not is_tampered:
            return (
                f"The image was classified as AUTHENTIC with "
                f"{conf_authentic * 100:.1f}% confidence. "
                "No significant ELA anomalies were detected and the classifier "
                "found no evidence of re-compression artefacts consistent with "
                "digital manipulation."
            )
        
        sw = exif_meta.get("Software", "")
        sw_msg = f" EXIF metadata reveals editing by \"{sw}\"." if sw else ""
        
        n = len(resnet_regions)
        if n > 0:
            top_r = max(resnet_regions, key=lambda r: r["area_pct"])
            top_s = top_r.get("area_pct", 0)
            agree = (f" The VGG16 and ResNet50 backbones agreed on "
                     f"{backbone_agree_pct:.1f}% of the flagged pixels."
                     if backbone_agree_pct is not None else "")
            
            return (
                f"The image was classified as TAMPERED with "
                f"{conf_tampered * 100:.1f}% confidence. "
                f"ELA analysis reveals mixed compression levels across the image, "
                f"a hallmark of localised editing. "
                f"{n} suspect region{'s' if n != 1 else ''} {'were' if n != 1 else 'was'} "
                f"identified, with the largest covering {top_s:.1f}% of the image area."
                f"{agree}{sw_msg}"
            )
        else:
            return (
                f"The image was classified as TAMPERED with "
                f"{conf_tampered * 100:.1f}% confidence. "
                f"While the classifier detected strong evidence of tampering, "
                f"the segmentation backbones did not isolate any specific localised "
                f"regions above the detection threshold. This suggests the manipulation "
                f"may be structural (e.g., global re-compression or metadata editing) "
                f"rather than a clear local splice.{sw_msg}"
            )

    # ── Build result dictionary ───────────────────────────────────────────────
    result = {
        "id":               result_id,
        "verdict":          verdict,
        "confidence_tampered":  conf_tampered,
        "confidence_authentic": conf_authentic,
        "inference_time_s": round(time.time() - t0, 3),
        "models_trained":   models_trained,
        "image_info": {
            "filename": os.path.basename(image_path),
            "width":    orig_w,
            "height":   orig_h,
            "mode":     original_pil.mode,
        },
        "ela": {
            "quality":    ela_quality,
            "hist_vals":  ela_hist_vals,
            "hist_bins":  ela_hist_bins,
        },
        "classification": {
            "is_tampered":  is_tampered,
            "confidence":   conf_tampered,
        },
        "segmentation": {
            "resnet50": {
                "severity_pct": resnet_sev,
                "regions":      resnet_regions,
            },
            "vgg16": {
                "severity_pct": vgg_sev,
                "regions":      vgg_regions,
            },
            "backbone_iou":         backbone_iou,
            "backbone_agree_pct":   backbone_agree_pct,
        },
        "gradcam": {},
        "paths": {
            "original":     orig_save,
            "ela":          ela_save,
            "gradcam":      gradcam_save,
            "overlay":      overlay_save,
            "vgg_mask":     vgg_mask_save,
            "resnet_mask":  resnet_mask_save,
            "agreement":    agree_save,
        },
        "exif":          exif_meta,
        "exif_warnings": exif_warnings,
        "explanation":   _explain(),
    }

    return result
