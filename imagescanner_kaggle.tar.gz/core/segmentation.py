import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

class UNetDecoderBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(UNetDecoderBlock, self).__init__()
        self.up = nn.ConvTranspose2d(in_channels, out_channels, kernel_size=2, stride=2)
        self.conv = nn.Sequential(
            nn.Conv2d(out_channels * 2, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x, skip):
        x = self.up(x)
        # Interpolate if spatial dims don't precisely match
        if x.size(2) != skip.size(2) or x.size(3) != skip.size(3):
            x = F.interpolate(x, size=(skip.size(2), skip.size(3)), mode='bilinear', align_corners=True)
        x = torch.cat([skip, x], dim=1)
        x = self.conv(x)
        return x

class VGG16_UNet(nn.Module):
    """
    Baseline architecture: VGG16 Encoder + U-Net Decoder.
    Highlights tampering regions generating a pixel level mask.
    """
    def __init__(self, out_classes=1):
        super(VGG16_UNet, self).__init__()
        vgg = models.vgg16(weights=models.VGG16_Weights.DEFAULT)
        features = list(vgg.features.children())
        
        # Encoder blocks
        self.enc1 = nn.Sequential(*features[:4])  # 64
        self.enc2 = nn.Sequential(*features[4:9]) # 128
        self.enc3 = nn.Sequential(*features[9:16]) # 256
        self.enc4 = nn.Sequential(*features[16:23]) # 512
        self.enc5 = nn.Sequential(*features[23:30]) # 512
        
        # Decoder blocks
        self.dec4 = UNetDecoderBlock(512, 512)
        self.dec3 = UNetDecoderBlock(512, 256)
        self.dec2 = UNetDecoderBlock(256, 128)
        self.dec1 = UNetDecoderBlock(128, 64)
        
        self.final = nn.Conv2d(64, out_classes, kernel_size=1)
        
    def forward(self, x):
        s1 = self.enc1(x)
        s2 = self.enc2(s1)
        s3 = self.enc3(s2)
        s4 = self.enc4(s3)
        b =  self.enc5(s4)
        
        d4 = self.dec4(b, s4)
        d3 = self.dec3(d4, s3)
        d2 = self.dec2(d3, s2)
        d1 = self.dec1(d2, s1)
        
        return torch.sigmoid(self.final(d1))


class ResNet50_UNet(nn.Module):
    """
    Improved architecture: ResNet50 Encoder + U-Net Decoder.
    Uses deep residual features for more reliable tampering localization.
    """
    def __init__(self, out_classes=1):
        super(ResNet50_UNet, self).__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        
        # Encoder blocks
        self.enc1 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu) # 64
        self.enc2 = nn.Sequential(resnet.maxpool, resnet.layer1)         # 256
        self.enc3 = resnet.layer2                                        # 512
        self.enc4 = resnet.layer3                                        # 1024
        self.enc5 = resnet.layer4                                        # 2048
        
        # Decoder blocks
        self.dec4 = UNetDecoderBlock(2048, 1024)
        self.dec3 = UNetDecoderBlock(1024, 512)
        self.dec2 = UNetDecoderBlock(512, 256)
        
        # dec1 handles transition from 256 back to 64
        self.up1 = nn.ConvTranspose2d(256, 64, kernel_size=2, stride=2)
        self.conv1 = nn.Sequential(
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        
        # final upsample to original resolution (Resnet initially downsampled strided by 2)
        self.final_up = nn.ConvTranspose2d(64, 64, kernel_size=2, stride=2)
        self.final = nn.Conv2d(64, out_classes, kernel_size=1)
        
    def forward(self, x):
        s1 = self.enc1(x)
        s2 = self.enc2(s1)
        s3 = self.enc3(s2)
        s4 = self.enc4(s3)
        b =  self.enc5(s4)
        
        d4 = self.dec4(b, s4)
        d3 = self.dec3(d4, s3)
        d2 = self.dec2(d3, s2)
        
        # Custom logic for the last layer corresponding to resnet's initial aggressive striding
        u1 = self.up1(d2)
        if u1.size(2) != s1.size(2) or u1.size(3) != s1.size(3):
            u1 = F.interpolate(u1, size=(s1.size(2), s1.size(3)), mode='bilinear', align_corners=True)
        c1 = torch.cat([s1, u1], dim=1)
        d1 = self.conv1(c1)
        
        out = self.final_up(d1)
        if out.size(2) != x.size(2) or out.size(3) != x.size(3):
            out = F.interpolate(out, size=(x.size(2), x.size(3)), mode='bilinear', align_corners=True)
            
        return torch.sigmoid(self.final(out))
