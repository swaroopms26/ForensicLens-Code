# ForensicLens — Image Forgery Detection & Localization System

> **M.Tech Final Year Project** — extends "Image Forgery Detection using VGG16-UNet Model"  
> (Choudhary et al., *Procedia Computer Science*, 2024)

---

## 🗂️ Project Structure

```
imagescanner/
├── config.py                    # Central config (paths, hyperparameters)
├── app.py                       # Flask web application
├── requirements.txt
├── README.md
├── core/
│   ├── ela.py                   # ELA preprocessing
│   ├── classifier.py            # CNN forgery classifier (Grad-CAM ready)
│   ├── segmentation.py          # VGG16-UNet + ResNet50-UNet
│   ├── datasets.py              # ForgeryDataset (CASIA + MICC)
│   ├── gradcam.py               # Grad-CAM saliency maps
│   └── inference.py             # Unified six-stage pipeline
├── scripts/
│   ├── download_data.py         # Kaggle dataset downloader
│   ├── train_classifier.py      # Classifier training + checkpoint
│   ├── train_segmentation.py    # Segmentation training (both backbones)
│   └── evaluate.py              # Full evaluation + plots + JSON summary
├── models/                      # Saved .pth checkpoints (created automatically)
├── data/                        # Downloaded datasets (created by download_data.py)
│   ├── casia/                   # CASIA v2.0
│   ├── columbia/                # Columbia Image Splicing
│   └── comofod/                 # CoMoFoD Small
├── static/
│   ├── css/style.css            # Dark/light forensic lab theme
│   ├── js/app.js                # Frontend interactions
│   ├── uploads/                 # Uploaded images (auto-created)
│   └── results/                 # Analysis output images (auto-created)
└── templates/
    ├── base.html                # Bootstrap 5 base layout + theme toggle
    ├── index.html               # Upload page with pipeline animation
    ├── result.html              # Full analysis dashboard
    ├── history.html             # SQLite history browser
    └── how_it_works.html        # Educational pipeline explainer
```

---

## ⚙️ Setup

### 1. Create virtual environment
```powershell
cd c:\Users\SIVANI\Desktop\imagescanner
python -m venv venv
.\venv\Scripts\activate
```

### 2. Install dependencies
```powershell
pip install -r requirements.txt
```

### 3. Configure Kaggle API
Place your `kaggle.json` at `C:\Users\SIVANI\.kaggle\kaggle.json`.

### 4. Download datasets
```powershell
python scripts/download_data.py
```
This downloads:
- **CASIA v2.0** (`sophatvathana/casia-dataset`) → `data/casia/`
- **Columbia** → `data/columbia/`
- **CoMoFoD Small** (Manual download required) → `data/comofod/`

After download, verify paths in `config.py`:
```python
CASIA_AUTHENTIC = "data/casia/CASIA2/Au"  # adjust if layout differs
CASIA_TAMPERED  = "data/casia/CASIA2/Tp"
CASIA_MASKS     = "data/casia/CASIA2/Gt"  # or "Masks"
COMOFOD_ORIGINAL = "data/comofod/original"
COMOFOD_FORGED   = "data/comofod/forged"
COMOFOD_MASKS    = "data/comofod/masks"
COLUMBIA_AUTHENTIC = "data/columbia/authentic"
COLUMBIA_TAMPERED  = "data/columbia/tampered"
COLUMBIA_MASKS     = "data/columbia/masks"
```

---

## 🏋️ Training

### Train classifier
```powershell
python scripts/train_classifier.py
# optional flags: --epochs 30 --batch-size 16 --lr 1e-4
```
Saves best checkpoint → `models/classifier_best.pth`

### Train segmentation models
```powershell
# Both backbones (recommended for comparison)
python scripts/train_segmentation.py

# Single backbone
python scripts/train_segmentation.py --backbone resnet50
python scripts/train_segmentation.py --backbone vgg16
```
Saves → `models/resnet50_unet_best.pth` and `models/vgg16_unet_best.pth`

---

## 📊 Evaluation
```powershell
python scripts/evaluate.py
```
Outputs:
| File | Description |
|------|-------------|
| `results/confusion_matrix.png` | CASIA test set confusion matrix |
| `results/roc_curve.png` | ROC + AUC curve |
| `results/backbone_comparison_casia.png` | VGG16 vs ResNet50 metrics bar chart on CASIA |
| `results/backbone_comparison_comofod.png` | VGG16 vs ResNet50 metrics bar chart on CoMoFoD |
| `results/backbone_comparison_columbia.png` | VGG16 vs ResNet50 metrics bar chart on Columbia |
| `results/eval_summary.json` | All metrics as JSON |

---

## 🌐 Run the Web App
```powershell
python app.py
```
Open **http://127.0.0.1:5000** in your browser.

> **Demo mode**: If model checkpoints are absent, the app still runs with randomly-initialized weights and shows a warning banner. This is useful for UI demonstration before training completes.

---

## 🔌 REST API

```bash
# Analyze an image
curl -X POST http://127.0.0.1:5000/api/analyze \
     -F "image=@photo.jpg" \
     -F "ela_quality=90"

# Re-analyze with different settings
curl -X POST http://127.0.0.1:5000/api/reanalyze/<id> \
     -H "Content-Type: application/json" \
     -d '{"ela_quality": 85, "seg_threshold": 0.35}'
```

---

## 🎨 Web App Features

| Feature | Description |
|---------|-------------|
| **Drag-and-drop upload** | File preview before submission |
| **ELA quality slider** | Tune re-compression quality (50–99) |
| **Pipeline animation** | Animated 6-step progress indicator during analysis |
| **Verdict donut gauge** | Chart.js tampered/authentic confidence |
| **Before/After slider** | Side-by-side original vs overlay comparison |
| **ELA histogram** | Bimodal detection — statistical evidence of editing |
| **Grad-CAM overlay** | Where the CNN focused to make its decision |
| **Backbone comparison** | VGG16 vs ResNet50 masks + agreement map |
| **Mask threshold slider** | Client-side Canvas re-render (instant) |
| **Region table** | Per-region bounding box, area %, severity |
| **EXIF forensics** | Software fingerprinting with warning badges |
| **AI explanation** | Auto-generated plain-language verdict paragraph |
| **PDF report** | Full ReportLab report (all images + tables) |
| **JSON export** | Complete analysis data export |
| **Batch upload** | Multiple files analyzed via REST API |
| **History** | SQLite with thumbnail grid, search, filter |
| **Dark / Light theme** | Persistent via localStorage |

---

## 🔬 Methodology (6-Stage Pipeline)

```
Input Image
    │
    ▼
[Stage 1] ELA Preprocessing
    JPEG re-save at quality 90 → pixel-wise difference → normalize
    │
    ▼
[Stage 2] Classification
    3-block CNN → sigmoid → authentic / tampered
    │
    ├── AUTHENTIC → stop, report
    ▼ TAMPERED
[Stage 3] Feature Encoding
    Pre-trained ResNet50 (primary) or VGG16 (baseline) encoder
    │
    ▼
[Stage 4] Mask Decoding
    U-Net decoder with skip connections → probability mask
    │
    ▼
[Stage 5] Localisation
    Threshold → binary mask → connected-component analysis
    Bounding boxes, severity %, backbone agreement map
    │
    ▼
[Stage 6] Report
    Grad-CAM + EXIF forensics + explanation → dashboard + PDF
```

---

## 📐 Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| ELA quality | 90 | Good sensitivity / noise trade-off |
| Loss (segmentation) | BCE + Dice (50/50) | Dice term stabilizes training with small tampered regions |
| Class imbalance | WeightedRandomSampler | CASIA has more authentic images |
| VGG16 fine-tuning | Freeze 5 epochs then unfreeze at 0.5× LR | Prevents destroying pretrained features early |
| ResNet50 fine-tuning | End-to-end from epoch 1 | Residual connections are more robust |
| Cross-Dataset eval | CoMoFoD + Columbia | Tests generalization to copy-move and splicing |
| PDF engine | ReportLab | Pure-Python, no wkhtmltopdf needed on Windows |
| History backend | SQLite (built-in) | No external DB needed at this scale |
| Theme | CSS variables + localStorage | Instant switch, no server round-trip |

---

## 📈 Expected Results (post-training)

| Metric | CASIA v2.0 (expected) | CoMoFoD (cross-dataset) | Columbia (cross-dataset) |
|--------|-----------------------|-------------------------|--------------------------|
| Classifier Accuracy | ~92–95% | ~85–90% | ~80–85% |
| Classifier AUC | ~0.95+ | ~0.88–0.93 | ~0.85–0.90 |
| ResNet50 IoU | ~0.72–0.78 | ~0.60–0.65 | ~0.55–0.60 |
| VGG16 IoU | ~0.65–0.72 | ~0.55–0.60 | ~0.50–0.55 |

> Actual numbers depend on dataset path correctness and hardware.  
> GPU strongly recommended (CUDA). CPU training is possible but slow.

---

## 🔮 What to Try Next

1. **Transformer encoder** (Swin-T or ViT) as a third backbone
2. **Frequency-domain features** (DCT) fused with ELA map
3. **Semi-supervised learning**
4. **Attention U-Net** decoder for finer mask boundaries
5. **Data augmentation**: JPEG compression, color jitter, copy-move synthesis

---

## 📝 Citation

Choudhary, A., Bhatt, U., & Trivedi, A. (2024). Image Forgery Detection System
using VGG16 UNET Model. *Procedia Computer Science*, 235, 3285–3294.
