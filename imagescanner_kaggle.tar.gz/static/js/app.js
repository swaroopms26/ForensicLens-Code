/**
 * ForensicLens — app.js
 * Theme toggle, drag-and-drop, batch upload, particle system,
 * counter animations, loading overlay pipeline.
 */

/* ── Theme ─────────────────────────────────────────────────────────────── */
(function () {
    const root = document.documentElement;
    const btn = document.getElementById("themeToggle");
    const icon = document.getElementById("themeIcon");
    const DARK = "dark";
    const LIGHT = "light";

    function apply(theme) {
        root.setAttribute("data-theme", theme);
        if (icon) {
            icon.className = theme === DARK
                ? "bi bi-moon-stars-fill"
                : "bi bi-sun-fill";
        }
        localStorage.setItem("fl-theme", theme);
    }

    const saved = localStorage.getItem("fl-theme") || DARK;
    apply(saved);

    if (btn) {
        btn.addEventListener("click", () => {
            const next = root.getAttribute("data-theme") === DARK ? LIGHT : DARK;
            apply(next);
        });
    }
})();

/* ── Particle / neural-network canvas ─────────────────────────────────── */
(function () {
    const canvas = document.getElementById("particleCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let W, H, particles = [], animId;

    const PARTICLE_COUNT = 50;
    const MAX_DIST = 140;

    function getAccent() {
        const theme = document.documentElement.getAttribute("data-theme");
        return theme === "light" ? "108,92,231" : "162,155,254";
    }

    function resize() {
        W = canvas.width = window.innerWidth;
        H = canvas.height = window.innerHeight;
    }

    function randBetween(a, b) { return a + Math.random() * (b - a); }

    function initParticles() {
        particles = [];
        for (let i = 0; i < PARTICLE_COUNT; i++) {
            particles.push({
                x: randBetween(0, W),
                y: randBetween(0, H),
                vx: randBetween(-0.35, 0.35),
                vy: randBetween(-0.35, 0.35),
                r: randBetween(1.5, 3),
            });
        }
    }

    function draw() {
        ctx.clearRect(0, 0, W, H);
        const ACCENT = getAccent();

        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < MAX_DIST) {
                    const alpha = (1 - d / MAX_DIST) * 0.35;
                    ctx.beginPath();
                    ctx.strokeStyle = `rgba(${ACCENT},${alpha})`;
                    ctx.lineWidth = 0.7;
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.stroke();
                }
            }
        }

        particles.forEach(p => {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${ACCENT},0.55)`;
            ctx.fill();

            p.x += p.vx;
            p.y += p.vy;
            if (p.x < 0 || p.x > W) p.vx *= -1;
            if (p.y < 0 || p.y > H) p.vy *= -1;
        });

        animId = requestAnimationFrame(draw);
    }

    resize();
    initParticles();
    draw();
    window.addEventListener("resize", () => {
        cancelAnimationFrame(animId);
        resize();
        initParticles();
        draw();
    });
})();

/* ── Animated stat counters ─────────────────────────────── */
(function () {
    function animateCounter(el, target, suffix = "", duration = 2000) {
        const start = performance.now();
        function step(now) {
            const t = Math.min((now - start) / duration, 1);
            const v = Math.floor(t * t * (3 - 2 * t) * target);
            el.textContent = v.toLocaleString() + suffix;
            if (t < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            const target = parseInt(el.dataset.count || "0", 10);
            const suffix = el.dataset.suffix || "";
            animateCounter(el, target, suffix);
            observer.unobserve(el);
        });
    }, { threshold: 0.5 });

    document.querySelectorAll("[data-count]").forEach(el => observer.observe(el));
})();

/* ── Drag & drop ─────────────────────────────────────────── */
(function () {
    const zone = document.getElementById("dropZone");
    const fileInput = document.getElementById("fileInput");
    const preview = document.getElementById("previewContainer");
    const dropCont = document.getElementById("dropContent");
    const img = document.getElementById("previewImg");
    const name = document.getElementById("previewName");
    const clearBtn = document.getElementById("clearFile");
    if (!zone) return;

    function showPreview(file) {
        const reader = new FileReader();
        reader.onload = e => {
            if (img) img.src = e.target.result;
            if (name) name.textContent = `${file.name}  (${(file.size / 1024).toFixed(0)} KB)`;
            if (preview) preview.classList.remove("d-none");
            if (dropCont) dropCont.classList.add("d-none");
        };
        reader.readAsDataURL(file);
    }

    function clearPreview() {
        if (fileInput) fileInput.value = "";
        if (preview) preview.classList.add("d-none");
        if (dropCont) dropCont.classList.remove("d-none");
        if (img) img.src = "";
    }

    ["dragenter", "dragover"].forEach(ev => {
        zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add("drag-over"); });
    });
    ["dragleave", "drop"].forEach(ev => {
        zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove("drag-over"); });
    });
    zone.addEventListener("drop", e => {
        const f = e.dataTransfer?.files?.[0];
        if (!f) return;
        const dt = new DataTransfer(); dt.items.add(f); fileInput.files = dt.files;
        showPreview(f);
    });
    fileInput?.addEventListener("change", function () {
        if (this.files?.[0]) showPreview(this.files[0]);
    });
    clearBtn?.addEventListener("click", clearPreview);
})();

/* ── Batch upload ────────────────────────────────────────── */
(function () {
    const batchInput = document.getElementById("batchInput");
    const queue = document.getElementById("batchQueue");
    const batchBtn = document.getElementById("batchBtn");
    if (!batchInput || !batchBtn) return;

    let batchFiles = [];

    batchInput.addEventListener("change", function () {
        batchFiles = Array.from(this.files || []);
        if (!queue) return;
        queue.innerHTML = batchFiles.map((f, i) =>
            `<div class="d-flex align-items-center gap-2 py-1 small text-muted" id="bq${i}">
         <i class="bi bi-image text-accent"></i>
         <span class="text-truncate flex-grow-1">${f.name}</span>
         <span class="fl-badge">pending</span>
       </div>`
        ).join("");
    });

    batchBtn.addEventListener("click", async function () {
        if (!batchFiles.length) { alert("Select files first."); return; }
        this.disabled = true;
        for (let i = 0; i < batchFiles.length; i++) {
            const item = document.getElementById(`bq${i}`);
            if (item) item.querySelector(".fl-badge").textContent = "analyzing…";
            const fd = new FormData();
            fd.append("image", batchFiles[i]);
            try {
                const res = await fetch("/api/analyze", { method: "POST", body: fd });
                const j = await res.json();
                if (item) {
                    const badge = item.querySelector(".fl-badge");
                    badge.textContent = j.verdict || "done";
                    badge.style.color = j.verdict === "TAMPERED" ? "var(--fl-danger)" : "var(--fl-success)";
                }
            } catch { if (item) item.querySelector(".fl-badge").textContent = "error"; }
        }
        this.disabled = false;
        this.innerHTML = '<i class="bi bi-check-circle me-2"></i>Done — check History';
    });
})();

/* ── Confidence bar entrance animation ───────────────────── */
(function () {
    const bars = document.querySelectorAll(".progress-bar");
    bars.forEach(bar => {
        const target = bar.style.width;
        bar.style.width = "0%";
        setTimeout(() => {
            bar.style.transition = "width 1.4s cubic-bezier(0.4,0,0.2,1)";
            bar.style.width = target;
        }, 500);
    });
})();

/* ── Loading overlay with pipeline step animation ─────────── */
document.getElementById("uploadForm")?.addEventListener("submit", function () {
    const fi = document.getElementById("fileInput");
    if (!fi?.value) return;
    document.getElementById("btnText")?.classList.add("d-none");
    document.getElementById("btnSpinner")?.classList.remove("d-none");
    document.getElementById("loadingOverlay")?.classList.remove("d-none");

    const steps = ["lstep0", "lstep1", "lstep2", "lstep3", "lstep4"];
    let i = 0;
    const iv = setInterval(() => {
        if (i > 0) {
            const prev = document.getElementById(steps[i - 1]);
            if (prev) {
                prev.classList.remove("active");
                prev.innerHTML = prev.innerHTML.replace("bi-circle", "bi-check-circle-fill");
            }
        }
        if (i < steps.length) {
            document.getElementById(steps[i])?.classList.add("active");
            i++;
        } else clearInterval(iv);
    }, 800);
});

/* ── Scroll reveal animation ──────────────────────────────── */
(function () {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll(".fl-card, .fl-feature-card, .fl-history-card").forEach(el => {
        el.style.opacity = "0";
        el.style.transform = "translateY(20px)";
        el.style.transition = "opacity 0.6s ease, transform 0.6s ease";
        observer.observe(el);
    });
})();
