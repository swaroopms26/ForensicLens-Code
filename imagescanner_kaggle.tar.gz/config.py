"""
config.py — Central configuration for the Image Forgery Detection System.

Design decision: all tuneable knobs live here so training scripts, inference,
and the Flask app all read from one place.  Paths are resolved relative to this
file so the project is portable across machines.
"""
import os
import torch

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Data paths ────────────────────────────────────────────────────────────────
DATA_ROOT = os.path.join(BASE_DIR, "data")

# CASIA v2.0  (sophatvathana/casia-dataset on Kaggle)
# After unzip the layout is typically:  data/casia/CASIA2/Au, .../Tp
# We try both layouts and fall back gracefully.
_casia_root = os.path.join(DATA_ROOT, "casia")
if os.path.isdir(os.path.join(_casia_root, "CASIA2")):
    _casia_root = os.path.join(_casia_root, "CASIA2")

CASIA_AUTHENTIC = os.path.join(_casia_root, "Au")
CASIA_TAMPERED  = os.path.join(_casia_root, "Tp")
# Ground-truth masks live in a "Gt" or "Masks" subfolder depending on source.
# Adjust CASIA_MASKS if your download differs.
CASIA_MASKS     = (
    os.path.join(_casia_root, "Gt")
    if os.path.isdir(os.path.join(_casia_root, "Gt"))
    else os.path.join(_casia_root, "Masks")
)

# ── Dataset 2: CoMoFoD Small (Cross-Dataset Testing WITH Masks) ───────────
# 200 image sets at 512×512, copy-move forgery with binary masks.
# Naming: NNN_O.png (original), NNN_F.png (forged), NNN_B.png (binary mask)
# After organising: data/comofod/original/  data/comofod/forged/  data/comofod/masks/
COMOFOD_ORIGINAL = os.path.join(DATA_ROOT, "comofod", "original")
COMOFOD_FORGED   = os.path.join(DATA_ROOT, "comofod", "forged")
COMOFOD_MASKS    = os.path.join(DATA_ROOT, "comofod", "masks")

# ── Dataset 3: Columbia Uncompressed Image Splicing Dataset ───────────────
# 183 authentic + 180 tampered spliced images, each with a binary mask.
# Hosted by DVMM Lab at Columbia University — downloaded via Kaggle mirror
# or from: https://www.ee.columbia.edu/ln/dvmm/downloads/AuthSplicedDataSet
# Layout expected: data/columbia/authentic/ data/columbia/tampered/ data/columbia/masks/
COLUMBIA_AUTHENTIC = os.path.join(DATA_ROOT, "columbia", "authentic")
COLUMBIA_TAMPERED  = os.path.join(DATA_ROOT, "columbia", "tampered")
COLUMBIA_MASKS     = os.path.join(DATA_ROOT, "columbia", "masks")

# ── Model checkpoints ─────────────────────────────────────────────────────────
MODELS_DIR          = os.path.join(BASE_DIR, "models")
CLASSIFIER_CKPT     = os.path.join(MODELS_DIR, "classifier_best.pth")
VGG16_SEG_CKPT      = os.path.join(MODELS_DIR, "vgg16_unet_best.pth")
RESNET50_SEG_CKPT   = os.path.join(MODELS_DIR, "resnet50_unet_best.pth")

os.makedirs(MODELS_DIR, exist_ok=True)

# ── Image pre-processing ──────────────────────────────────────────────────────
IMG_SIZE    = (256, 256)   # (H, W) — both models expect this spatial size
ELA_QUALITY = 90           # JPEG re-save quality; lower → more ELA amplification

# ── Training hyper-parameters ─────────────────────────────────────────────────
BATCH_SIZE   = 16
EPOCHS_CLS   = 30
EPOCHS_SEG   = 40
LR_CLS       = 1e-4
LR_SEG       = 1e-4
WEIGHT_DECAY = 1e-5
VAL_SPLIT    = 0.10        # 10 % of data held out for validation
TEST_SPLIT   = 0.20        # 20 % held out as the unseen test set
SPLIT_SEED   = 42          # fixed seed — must match across train + evaluate
EARLY_STOP   = 7           # patience (epochs without improvement)

# ── Inference thresholds ──────────────────────────────────────────────────────
DEVICE        = "cuda" if torch.cuda.is_available() else "cpu"
CLS_THRESHOLD = 0.50       # classifier sigmoid ≥ this  →  TAMPERED
SEG_THRESHOLD = 0.55       # mask pixel ≥ this           →  forged region

# ── Flask ─────────────────────────────────────────────────────────────────────
SECRET_KEY          = os.environ.get("FLASK_SECRET", "forensics-ima-2024-secret")
UPLOAD_FOLDER       = os.path.join(BASE_DIR, "static", "uploads")
RESULTS_FOLDER      = os.path.join(BASE_DIR, "static", "results")
HISTORY_DB          = os.path.join(BASE_DIR, "history.db")
MAX_CONTENT_LENGTH  = 16 * 1024 * 1024   # 16 MB
ALLOWED_EXTENSIONS  = {"png", "jpg", "jpeg", "tif", "tiff", "bmp"}

os.makedirs(UPLOAD_FOLDER,  exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)
